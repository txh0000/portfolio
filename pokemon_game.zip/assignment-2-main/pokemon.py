"""
    Pokemon is a class which has all the pokemon types.

"""
__author__ = "Scaffold by Jackson Goerner, Code by Lim Jun Kee, Lim Wei En, Heng Zi Ying, Toh Xi Heng"
from pokemon_base import *

class Charmander(PokemonBase):
    """Class which represents a Charmander pokemon inheriting PokemonBase.

    Attributes:
        pokemonLevel (int): pokemon's level
        maxHealthPoint (int): pokemon's max health 
        currentHealthPoint (int): pokemon's current health
        pokemonType (PokeType): pokemon's element
        pokemonName (str): pokemon's name
        pokemonAttackDamage (int): pokemon's attack damage
        pokemonSpeed (int): pokemon's speed
        pokemonDefense (int): pokemon's defense
        pokemonStatus (str): pokemon's status
    """


    def __init__(self):
        """
        Instantiates Charmander object.

        """
        self.pokemonLevel=1
        super().__init__(8+(1*self.get_level()),PokeType.FIRE)
        self.pokemonName="Charmander"
        self.pokemonAttackDamage=6+(1*self.get_level())
        self.pokemonSpeed=7+(1*self.get_level())
        self.pokemonDefence=4



    def level_up(self) -> None:
        """
        Method which is used to + 1 to the pokemonLevel of the Charmander object.
        This method changes the maxHealthPoint, currentHealthPoint, pokemonAttackDamage and pokemonSpeed according to the requirement.

        Best-case complexity: O(1).
        Worst-case complexity: O(1).

        """
        self.pokemonLevel+=1
        totalHpLost = self.get_total_hp_lost()
        self.maxHealthPoint=8+(1*self.get_level())
        self.currentHealthPoint = self.maxHealthPoint - (totalHpLost)
        self.pokemonAttackDamage = 6 + (1 * self.get_level())

        if self.pokemonStatus == "paralysis":
            self.pokemonSpeed = (7 + (1 * self.get_level()))//2
        else:
            self.pokemonSpeed = (7 + (1 * self.get_level()))



    def defend(self, damage: int) -> None:
        """
        Method used to check how much health is lost by comparing the damage (int) and the pokemonDefence of the Charmander object.
        
        Parameter:
                    damage (int): the damage taken.

        Best-case complexity: O(1).
        Worst-case complexity: O(1).

        """

        if damage>self.get_defence():
            self.lose_hp(damage)
        else:
            self.lose_hp(damage//2)



    def can_evolve(self) -> bool:
        """
        Method used to check if the Charmander object can evolve into another pokemon.

        Return:
                boolean True or False.

        Best-case complexity: O(1).
        Worst-case complexity: O(1).

        """
        return True



    def should_evolve(self) -> bool:
        """
        Method used to check if the Charmander object should evolve into another pokemon according to the level, can_evolve() method and is.fainted() method.

        Return:
                boolean True or False.

        Best-case complexity: O(1).
        Worst-case complexity: O(1).
        
        """
        if self.get_level()>=3 and self.can_evolve() and self.is_fainted()!=True:
            return True

        return False



    def get_evolved_version(self) -> PokemonBase:
        """
        Method used to return an evolved version of the Charmander object according to the should_evolve() method.

        Return:
                Exception or Charizard object.

        Best-case complexity: O(1).
        Worst-case complexity: O(1).
        
        """
        if self.should_evolve() == False:
            raise Exception("This pokemon can't evolve.")
        else:
            charizardObj=Charizard()
            charizardObj.currentHealthPoint-=self.get_total_hp_lost()
            charizardObj.pokemonStatus=self.pokemonStatus
            return charizardObj



class Squirtle(PokemonBase):
    """Class which represents a Squirtle pokemon inheriting PokemonBase.

    Attributes:
        pokemonLevel (int): pokemon's level
        maxHealthPoint (int): pokemon's max health 
        currentHealthPoint (int): pokemon's current health
        pokemonType (PokeType): pokemon's element
        pokemonName (str): pokemon's name
        pokemonAttackDamage (int): pokemon's attack damage
        pokemonSpeed (int): pokemon's speed
        pokemonDefense (int): pokemon's defense
        pokemonStatus (str): pokemon's status
    """



    def __init__(self):
        """
        Instantiates Squirtle object.

        """        
        self.pokemonLevel=1
        super().__init__(9+(2*self.get_level()), PokeType.WATER)
        self.pokemonName="Squirtle"
        self.pokemonAttackDamage=4+(self.get_level()//2)
        self.pokemonSpeed=7
        self.pokemonDefence=6+self.get_level()



    def level_up(self) -> None:
        """
        Method which is used to + 1 to the pokemonLevel of the Squirtle object.
        This method changes the maxHealthPoint, currentHealthPoint, pokemonAttackDamage and pokemonSpeed according to the requirement.

        Best-case complexity: O(1).
        Worst-case complexity: O(1).

        """
        self.pokemonLevel+=1
        totalHpLost = self.get_total_hp_lost()
        self.maxHealthPoint=9+(2*self.get_level())
        self.currentHealthPoint=self.maxHealthPoint-(totalHpLost)
        self.pokemonAttackDamage = 4 + (self.get_level() // 2)
        self.pokemonDefence = 6 + self.get_level()



    def defend(self, damage: int) -> None:
        """
        Method used to check how much health is lost by comparing the damage (int) and the pokemonDefence of the Squirtle object.
        
        Parameter:
                damage (int): the damage taken.

        Best-case complexity: O(1).
        Worst-case complexity: O(1).

        """
        if damage>(self.get_defence()*2):
            self.lose_hp(damage)
        else:
            self.lose_hp(damage//2)



    def can_evolve(self) -> bool:
        """
        Method used to check if the Squirtle object can evolve into another pokemon.

        Return:
                boolean True or False.

        Best-case complexity: O(1).
        Worst-case complexity: O(1).

        """
        return True



    def should_evolve(self) -> bool:
        """
        Method used to check if the Squirtle object should evolve into another pokemon according to the level, can_evolve() method and is.fainted() method.

        Return:
                boolean True or False.

        Best-case complexity: O(1).
        Worst-case complexity: O(1).
        
        """
        if self.get_level()>=3 and self.can_evolve() and self.is_fainted()!=True:
            return True
        return False



    def get_evolved_version(self) -> PokemonBase:
        """
        Method used to return an evolved version of the Squirtle object according to the should_evolve() method.

        Return:
                Exception or Blastoise object.

        Best-case complexity: O(1).
        Worst-case complexity: O(1).
        
        """

        if self.should_evolve() == False:
            raise Exception("This pokemon can't evolve.")
        else:
            blastoiseObj=Blastoise()
            blastoiseObj.currentHealthPoint-=self.get_total_hp_lost()
            blastoiseObj.pokemonStatus=self.pokemonStatus
            return blastoiseObj



class Bulbasaur(PokemonBase):
    """Class which represents a Bulbasaur pokemon inheriting PokemonBase.

    Attributes:
        pokemonLevel (int): pokemon's level
        maxHealthPoint (int): pokemon's max health 
        currentHealthPoint (int): pokemon's current health
        pokemonType (PokeType): pokemon's element
        pokemonName (str): pokemon's name
        pokemonAttackDamage (int): pokemon's attack damage
        pokemonSpeed (int): pokemon's speed
        pokemonDefense (int): pokemon's defense
        pokemonStatus (str): pokemon's status
    """



    def __init__(self):
        """
        Instantiates Bulbasaur object.

        """        

        self.pokemonLevel=1
        super().__init__(12+(1*self.get_level()), PokeType.GRASS)
        self.pokemonName="Bulbasaur"
        self.pokemonAttackDamage=5
        self.pokemonSpeed=7+(self.get_level()//2)
        self.pokemonDefence=5



    def level_up(self) -> None:
        """
        Method which is used to + 1 to the pokemonLevel of the Bulbasaur object.
        This method changes the maxHealthPoint, currentHealthPoint, pokemonAttackDamage and pokemonSpeed according to the requirement.

        Best-case complexity: O(1).
        Worst-case complexity: O(1).

        """

        self.pokemonLevel+=1
        totalHpLost = self.get_total_hp_lost()
        self.maxHealthPoint=12+(1*self.get_level())
        self.currentHealthPoint=self.maxHealthPoint-(totalHpLost)
        if self.pokemonStatus=="paralysis":
            self.pokemonSpeed=(7+(self.get_level()//2))//2

        else:
            self.pokemonSpeed = (7 + (self.get_level() // 2))


    def defend(self, damage: int) -> None:
        """
        Method used to check how much health is lost by comparing the damage (int) and the pokemonDefence of the Bulbasaur object.
        
        Parameter:
                damage (int): the damage taken.

        Best-case complexity: O(1).
        Worst-case complexity: O(1).

        """

        if damage > (self.get_defence() + 5):
            self.lose_hp(damage)
        else:
            self.lose_hp(damage // 2)



    def can_evolve(self) -> bool:
        """
        Method used to check if the Bulbasaur object can evolve into another pokemon.

        Return:
                boolean True or False.

        Best-case complexity: O(1).
        Worst-case complexity: O(1).

        """
        return True



    def should_evolve(self) -> bool:
        """
        Method used to check if the Bulbasaur object should evolve into another pokemon according to the level, can_evolve() method and is.fainted() method.

        Return:
                boolean True or False.

        Best-case complexity: O(1).
        Worst-case complexity: O(1).
        
        """
        if self.get_level()>=2 and self.can_evolve() and self.is_fainted()!=True:
            return True
        return False



    def get_evolved_version(self) -> PokemonBase:
        """
        Method used to return an evolved version of the Bulbasaur object according to the should_evolve() method.

        Return:
                Exception or Venusaur object.

        Best-case complexity: O(1).
        Worst-case complexity: O(1).
        
        """

        if self.should_evolve() == False:
            raise Exception("This pokemon can't evolve.")
        else:
            venusaurObj=Venusaur()
            venusaurObj.currentHealthPoint-=self.get_total_hp_lost()
            venusaurObj.pokemonStatus=self.pokemonStatus
            return venusaurObj



class Gastly(PokemonBase):
    """Class which represents a Gastly pokemon inheriting PokemonBase.

    Attributes:
        pokemonLevel (int): pokemon's level
        maxHealthPoint (int): pokemon's max health 
        currentHealthPoint (int): pokemon's current health
        pokemonType (PokeType): pokemon's element
        pokemonName (str): pokemon's name
        pokemonAttackDamage (int): pokemon's attack damage
        pokemonSpeed (int): pokemon's speed
        pokemonDefense (int): pokemon's defense
        pokemonStatus (str): pokemon's status
    """



    def __init__(self):
        """
        Instantiates Gastly object.

        """        

        self.pokemonLevel=1
        super().__init__(6+(self.get_level()//2), PokeType.GHOST)
        self.pokemonName="Gastly"
        self.pokemonAttackDamage=4
        self.pokemonSpeed=2
        self.pokemonDefence=8



    def level_up(self) -> None:
        """
        Method which is used to + 1 to the pokemonLevel of the Gastly object.
        This method changes the maxHealthPoint, currentHealthPoint, pokemonAttackDamage and pokemonSpeed according to the requirement.

        Best-case complexity: O(1).
        Worst-case complexity: O(1).

        """

        self.pokemonLevel+=1
        totalHpLost = self.get_total_hp_lost()
        self.maxHealthPoint=6+(self.get_level()//2)
        self.currentHealthPoint=self.maxHealthPoint-(totalHpLost)



    def defend(self, damage: int) -> None:
        """
        Method used to check how much health is lost by comparing the damage (int) and the pokemonDefence of the Gastly object.
        
        Parameter:
                damage (int): the damage taken.

        Best-case complexity: O(1).
        Worst-case complexity: O(1).

        """

        self.lose_hp(damage)



    def can_evolve(self) -> bool:
        """
        Method used to check if the Gastly object can evolve into another pokemon.

        Return:
                boolean True or False.

        Best-case complexity: O(1).
        Worst-case complexity: O(1).

        """
        return True

    def should_evolve(self) -> bool:
        """
        Method used to check if the Gastly object should evolve into another pokemon according to the level, can_evolve() method and is.fainted() method.

        Return:
                boolean True or False.

        Best-case complexity: O(1).
        Worst-case complexity: O(1).
        
        """
        if self.get_level()>=1 and self.is_fainted()!=True and self.can_evolve():
            return True
        return False



    def get_evolved_version(self) -> PokemonBase:
        """
        Method used to return an evolved version of the Gastly object according to the should_evolve() method.

        Return:
                Exception or Haunter object.

        Best-case complexity: O(1).
        Worst-case complexity: O(n).
        
        """

        if self.should_evolve()==False:
            raise Exception("This pokemon can't evolve.")
        else:
            haunterObj=Haunter()
            haunterObj.currentHealthPoint-=self.get_total_hp_lost()
            for i in range(self.get_level()-1):
                haunterObj.level_up()
            haunterObj.pokemonStatus=self.pokemonStatus

            return haunterObj



class Eevee(PokemonBase):
    """Class which represents a Eevee pokemon inheriting PokemonBase.

    Attributes:
        pokemonLevel (int): pokemon's level
        maxHealthPoint (int): pokemon's max health 
        currentHealthPoint (int): pokemon's current health
        pokemonType (PokeType): pokemon's element
        pokemonName (str): pokemon's name
        pokemonAttackDamage (int): pokemon's attack damage
        pokemonSpeed (int): pokemon's speed
        pokemonDefense (int): pokemon's defense
        pokemonStatus (str): pokemon's status
    """



    def __init__(self):
        """
        Instantiates Eevee object.

        """        

        self.pokemonLevel=1
        super().__init__(10, PokeType.NORMAL)
        self.pokemonName="Eevee"
        self.pokemonAttackDamage=6+self.get_level()
        self.pokemonSpeed=7+self.get_level()
        self.pokemonDefence=4+self.get_level()



    def level_up(self) -> None:
        """
        Method which is used to + 1 to the pokemonLevel of the Eevee object.
        This method changes the maxHealthPoint, currentHealthPoint, pokemonAttackDamage and pokemonSpeed according to the requirement.

        Best-case complexity: O(1).
        Worst-case complexity: O(1).

        """

        self.pokemonLevel+=1
        totalHpLost = self.get_total_hp_lost()
        self.currentHealthPoint=self.maxHealthPoint-(totalHpLost)
        self.pokemonAttackDamage = 6 + self.get_level()
        if self.pokemonStatus=="paralysis":
            self.pokemonSpeed = (7 + self.get_level())//2
        else:
            self.pokemonSpeed = 7 + self.get_level()

        self.pokemonDefence = 4 + self.get_level()


    def defend(self, damage: int) -> None:
        """
        Method used to check how much health is lost by comparing the damage (int) and the pokemonDefence of the Eevee object.
        
        Parameter:
                damage (int): the damage taken.

        Best-case complexity: O(1).
        Worst-case complexity: O(1).

        """


        if damage>=self.get_defence():
            self.lose_hp(damage)



    def can_evolve(self) -> bool:
        """
        Method used to check if the Eevee object can evolve into another pokemon.

        Return:
                boolean True or False.

        Best-case complexity: O(1).
        Worst-case complexity: O(1).

        """
        return False



    def should_evolve(self) -> bool:
        """
        Method used to check if the Eevee object should evolve into another pokemon according to the level, can_evolve() method and is.fainted() method.

        Return:
                boolean True or False.

        Best-case complexity: O(1).
        Worst-case complexity: O(1).
        
        """
        return False



    def get_evolved_version(self) -> PokemonBase:
        """
        Method used to return an evolved version of the Eevee object according to the should_evolve() method.

        Raise:
                Exception.

        Best-case complexity: O(1).
        Worst-case complexity: O(1).
        
        """
        if self.should_evolve()==False:
            raise Exception("This pokemon can't evolve.")



class Charizard(PokemonBase):
    """Class which represents a Charizard pokemon inheriting PokemonBase.

    Attributes:
        pokemonLevel (int): pokemon's level
        maxHealthPoint (int): pokemon's max health 
        currentHealthPoint (int): pokemon's current health
        pokemonType (PokeType): pokemon's element
        pokemonName (str): pokemon's name
        pokemonAttackDamage (int): pokemon's attack damage
        pokemonSpeed (int): pokemon's speed
        pokemonDefense (int): pokemon's defense
        pokemonStatus (str): pokemon's status
    """



    def __init__(self):
        """
        Instantiates Charizard object.

        """        

        self.pokemonLevel = 3
        super().__init__(12+(1*self.get_level()),PokeType.FIRE)
        self.pokemonName="Charizard"
        self.pokemonAttackDamage=10+(2*self.get_level())
        self.pokemonSpeed=9+(1*self.get_level())
        self.pokemonDefence=4



    def level_up(self) -> None:
        """
        Method which is used to + 1 to the pokemonLevel of the Charizard object.
        This method changes the maxHealthPoint, currentHealthPoint, pokemonAttackDamage and pokemonSpeed according to the requirement.

        Best-case complexity: O(1).
        Worst-case complexity: O(1).

        """

        self.pokemonLevel+=1
        totalHpLost=self.get_total_hp_lost()##To get the old maxHealthPoint
        self.maxHealthPoint=12+(1*self.get_level())
        self.currentHealthPoint=self.maxHealthPoint-(totalHpLost)
        self.pokemonAttackDamage = 10 + (2 * self.get_level())
        if self.pokemonStatus=="paralysis":
            self.pokemonSpeed = (9 + (1 * self.get_level()))//2
        else:
            self.pokemonSpeed = (9 + (1 * self.get_level()))



    def defend(self, damage: int) -> None:
        """
        Method used to check how much health is lost by comparing the damage (int) and the pokemonDefence of the Charizard object.
        
        Parameter:
                damage (int): the damage taken.

        Best-case complexity: O(1).
        Worst-case complexity: O(1).

        """

        if damage>self.get_defence():
            self.lose_hp(2*damage)
        else:
            self.lose_hp(damage)



    def can_evolve(self) -> bool:
        """
        Method used to check if the Charizard object can evolve into another pokemon.

        Return:
                boolean True or False.

        Best-case complexity: O(1).
        Worst-case complexity: O(1).

        """
        return False



    def should_evolve(self) -> bool:
        """
        Method used to check if the Charizard object should evolve into another pokemon according to the level, can_evolve() method and is.fainted() method.

        Return:
                boolean True or False.

        Best-case complexity: O(1).
        Worst-case complexity: O(1).
        
        """
        return False



    def get_evolved_version(self) -> PokemonBase:
        """
        Method used to return an evolved version of the Chrarizard object according to the should_evolve() method.

        Raise:
                Exception.

        Best-case complexity: O(1).
        Worst-case complexity: O(1).
        
        """

        if self.should_evolve()==False:
            raise Exception("This pokemon can't evolve.")



class Blastoise(PokemonBase):
    """Class which represents a Blastoise pokemon inheriting PokemonBase.

    Attributes:
        pokemonLevel (int): pokemon's level
        maxHealthPoint (int): pokemon's max health 
        currentHealthPoint (int): pokemon's current health
        pokemonType (PokeType): pokemon's element
        pokemonName (str): pokemon's name
        pokemonAttackDamage (int): pokemon's attack damage
        pokemonSpeed (int): pokemon's speed
        pokemonDefense (int): pokemon's defense
        pokemonStatus (str): pokemon's status
    """



    def __init__(self):
        """
        Instantiates Blastoise object.

        """        

        self.pokemonLevel = 3
        super().__init__(15+(2*self.get_level()), PokeType.WATER)
        self.pokemonName="Blastoise"
        self.pokemonAttackDamage=8+(self.get_level()//2)
        self.pokemonSpeed=10
        self.pokemonDefence=8+(1*self.get_level())



    def level_up(self) -> None:
        """
        Method which is used to + 1 to the pokemonLevel of the Blastoise object.
        This method changes the maxHealthPoint, currentHealthPoint, pokemonAttackDamage and pokemonSpeed according to the requirement.

        Best-case complexity: O(1).
        Worst-case complexity: O(1).

        """

        self.pokemonLevel+=1
        totalHpLost = self.get_total_hp_lost()
        self.maxHealthPoint=15+(2*self.get_level())
        self.currentHealthPoint=self.maxHealthPoint-(totalHpLost)
        self.pokemonAttackDamage = 8 + (self.get_level() // 2)
        self.pokemonDefence = 8 + (1 * self.get_level())


    def defend(self, damage: int) -> None:
        """
        Method used to check how much health is lost by comparing the damage (int) and the pokemonDefence of the Blastoise object.
        
        Parameter:
                damage (int): the damage taken.

        Best-case complexity: O(1).
        Worst-case complexity: O(1).

        """

        if damage>(self.get_defence()*2):
            self.lose_hp(damage)
        else:
            self.lose_hp(damage//2)



    def can_evolve(self) -> bool:
        """
        Method used to check if the Blastoise object can evolve into another pokemon.

        Return:
                boolean True or False.

        Best-case complexity: O(1).
        Worst-case complexity: O(1).

        """
        return False



    def should_evolve(self) -> bool:
        """
        Method used to check if the Blastoise object should evolve into another pokemon according to the level, can_evolve() method and is.fainted() method.

        Return:
                boolean True or False.

        Best-case complexity: O(1).
        Worst-case complexity: O(1).
        
        """
        return False



    def get_evolved_version(self) -> PokemonBase:
        """
        Method used to return an evolved version of the Blastoise object according to the should_evolve() method.

        Raise:
                Exception.

        Best-case complexity: O(1).
        Worst-case complexity: O(1).
        
        """

        if self.should_evolve() == False:
            raise Exception("This pokemon can't evolve.")



class Venusaur(PokemonBase):
    """Class which represents a Venusaur pokemon inheriting PokemonBase.

    Attributes:
        pokemonLevel (int): pokemon's level
        maxHealthPoint (int): pokemon's max health 
        currentHealthPoint (int): pokemon's current health
        pokemonType (PokeType): pokemon's element
        pokemonName (str): pokemon's name
        pokemonAttackDamage (int): pokemon's attack damage
        pokemonSpeed (int): pokemon's speed
        pokemonDefense (int): pokemon's defense
        pokemonStatus (str): pokemon's status
    """



    def __init__(self):
        """
        Instantiates Venusaur object.

        """        

        self.pokemonLevel = 2
        super().__init__(20+(self.get_level()//2), PokeType.GRASS)
        self.pokemonName="Venusaur"
        self.pokemonAttackDamage=5
        self.pokemonSpeed=3+(self.get_level()//2)
        self.pokemonDefence=10


    def level_up(self) -> None:
        """
        Method which is used to + 1 to the pokemonLevel of the Venusaur object.
        This method changes the maxHealthPoint, currentHealthPoint, pokemonAttackDamage and pokemonSpeed according to the requirement.

        Best-case complexity: O(1).
        Worst-case complexity: O(1).

        """

        self.pokemonLevel+=1
        totalHpLost = self.get_total_hp_lost()
        self.maxHealthPoint=20+(self.get_level()//2)
        self.currentHealthPoint=self.maxHealthPoint-(totalHpLost)
        if self.pokemonStatus == "paralysis":
            self.pokemonSpeed = (3 + (self.get_level() // 2))//2
        else:
            self.pokemonSpeed = (3 + (self.get_level() // 2))


    def defend(self, damage: int) -> None:
        """
        Method used to check how much health is lost by comparing the damage (int) and the pokemonDefence of the Venusaur object.
        
        Parameter:
                damage (int): the damage taken.

        Best-case complexity: O(1).
        Worst-case complexity: O(1).

        """

        if damage>(self.get_defence()+5):
            self.lose_hp(damage)
        else:
            self.lose_hp(damage//2)



    def can_evolve(self) -> bool:
        """
        Method used to check if the Venusaur object can evolve into another pokemon.

        Return:
                boolean True or False.

        Best-case complexity: O(1).
        Worst-case complexity: O(1).

        """
        return False



    def should_evolve(self) -> bool:
        """
        Method used to check if the Venusaur object should evolve into another pokemon according to the level, can_evolve() method and is.fainted() method.

        Return:
                boolean True or False.

        Best-case complexity: O(1).
        Worst-case complexity: O(1).
        
        """

        return False



    def get_evolved_version(self) -> PokemonBase:
        """
        Method used to return an evolved version of the Venusaur object according to the should_evolve() method.

        Raise:
                Exception.

        Best-case complexity: O(1).
        Worst-case complexity: O(1).
        
        """
        if self.should_evolve() == False:
            raise Exception("This pokemon can't evolve.")



class Haunter(PokemonBase):
    """Class which represents a Haunter pokemon inheriting PokemonBase.

    Attributes:
        pokemonLevel (int): pokemon's level
        maxHealthPoint (int): pokemon's max health 
        currentHealthPoint (int): pokemon's current health
        pokemonType (PokeType): pokemon's element
        pokemonName (str): pokemon's name
        pokemonAttackDamage (int): pokemon's attack damage
        pokemonSpeed (int): pokemon's speed
        pokemonDefense (int): pokemon's defense
        pokemonStatus (str): pokemon's status
    """



    def __init__(self):
        """
        Instantiates Haunter object.

        """        

        self.pokemonLevel=1
        super().__init__(9+(self.get_level()//2), PokeType.GHOST)
        self.pokemonName="Haunter"
        self.pokemonAttackDamage=8
        self.pokemonSpeed=6
        self.pokemonDefence=6



    def level_up(self) -> None:
        """
        Method which is used to + 1 to the pokemonLevel of the Haunter object.
        This method changes the maxHealthPoint, currentHealthPoint, pokemonAttackDamage and pokemonSpeed according to the requirement.

        Best-case complexity: O(1).
        Worst-case complexity: O(1).

        """

        self.pokemonLevel+=1
        totalHpLost = self.get_total_hp_lost()
        self.maxHealthPoint=9+(self.get_level()//2)
        self.currentHealthPoint=self.maxHealthPoint-(totalHpLost)



    def defend(self, damage: int) -> None:
        """
        Method used to check how much health is lost by comparing the damage (int) and the pokemonDefence of the Haunter object.
        
        Parameter:
                damage (int): the damage taken.

        Best-case complexity: O(1).
        Worst-case complexity: O(1).

        """

        self.lose_hp(damage)



    def can_evolve(self) -> bool:
        """
        Method used to check if the Haunter object can evolve into another pokemon.

        Return:
                boolean True or False.

        Best-case complexity: O(1).
        Worst-case complexity: O(1).

        """
        return True



    def should_evolve(self) -> bool:
        """
        Method used to check if the Haunter object should evolve into another pokemon according to the level, can_evolve() method and is.fainted() method.

        Return:
                boolean True or False.

        Best-case complexity: O(1).
        Worst-case complexity: O(1).
        
        """    
        if self.get_level() >= 3 and self.is_fainted() != True and self.can_evolve():
            return True
        return False



    def get_evolved_version(self) -> PokemonBase:
        """
        Method used to return an evolved version of the Haunter object according to the should_evolve() method.

        Rreturn:
                Exception or Gengar object.

        Best-case complexity: O(1).
        Worst-case complexity: O(1).
        
        """

        if self.should_evolve()==False:
            raise Exception("This pokemon can't evolve.")
        else:
            gengarObj=Gengar()
            gengarObj.currentHealthPoint-=self.get_total_hp_lost()
            gengarObj.pokemonStatus=self.pokemonStatus
            return gengarObj



class Gengar(PokemonBase):
    """Class which represents a Gengar pokemon inheriting PokemonBase.

    Attributes:
        pokemonLevel (int): pokemon's level
        maxHealthPoint (int): pokemon's max health 
        currentHealthPoint (int): pokemon's current health
        pokemonType (PokeType): pokemon's element
        pokemonName (str): pokemon's name
        pokemonAttackDamage (int): pokemon's attack damage
        pokemonSpeed (int): pokemon's speed
        pokemonDefense (int): pokemon's defense
        pokemonStatus (str): pokemon's status
    """



    def __init__(self):
        """
        Instantiates Gengar object.

        """        

        self.pokemonLevel = 3
        super().__init__(12+(self.get_level()//2), PokeType.GHOST)
        self.pokemonName="Gengar"
        self.pokemonAttackDamage=18
        self.pokemonSpeed=12
        self.pokemonDefence=3



    def level_up(self) -> None:
        """
        Method which is used to + 1 to the pokemonLevel of the gengar object.
        This method changes the maxHealthPoint, currentHealthPoint, pokemonAttackDamage and pokemonSpeed according to the requirement.

        Best-case complexity: O(1).
        Worst-case complexity: O(1).

        """

        self.pokemonLevel+=1
        totalHpLost = self.get_total_hp_lost()
        self.maxHealthPoint=12+(self.get_level()//2)
        self.currentHealthPoint=self.maxHealthPoint-(totalHpLost)



    def defend(self, damage: int) -> None:
        """
        Method used to check how much health is lost by comparing the damage (int) and the pokemonDefence of the Gengar object.
        
        Parameter:
                damage (int): the damage taken.

        Best-case complexity: O(1).
        Worst-case complexity: O(1).

        """

        self.lose_hp(damage)



    def can_evolve(self) -> bool:
        """
        Method used to check if the Gengar object can evolve into another pokemon.

        Return:
                boolean True or False.

        Best-case complexity: O(1).
        Worst-case complexity: O(1).

        """
        return False



    def should_evolve(self) -> bool:
        """
        Method used to check if the Gengar object should evolve into another pokemon according to the level, can_evolve() method and is.fainted() method.

        Return:
                boolean True or False.

        Best-case complexity: O(1).
        Worst-case complexity: O(1).
        
        """        
        return False



    def get_evolved_version(self) -> PokemonBase:
        """
        Method used to return an evolved version of the Gengar object according to the should_evolve() method.

        Raise:
                Exception.

        Best-case complexity: O(1).
        Worst-case complexity: O(1).
        
        """
        if self.should_evolve()==False:
            raise Exception("This pokemon can't evolve.")