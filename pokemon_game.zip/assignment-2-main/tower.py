from __future__ import annotations
"""
Tower is a class that enables multiple battles.
"""
__author__ = "Scaffold by Jackson Goerner, Code by Lim Jun Kee, Lim Wei En, Heng Zi Ying, Toh Xi Heng"
from poke_team import PokeTeam
from battle import Battle
from queue_adt import *
from random_gen import *
class BattleTower:
    """
        A class used to represent the battle tower.

        Attributes:
        __________
        battleArena: battle --> used for actual battle
        towerTeams: PokeTeam --> Poke team in the tower
        playerTeam: PokeTeam --> Player team that used to battle through the tower

    """

    def __init__(self, battle: Battle|None=None) -> None:
        """
           Function that instantiate the Battletower.

           Parameters:
           ----------
           self : used to access variables that belong to the class.
           battleArena: battle --> used for actual battle

           Returns:
           --------
           *None

           Complexity:
           ----------
           Best-case : O(1)
           Worst-case : O(1)

        """
        self.battleArena=battle
        self.towerTeams=None
        self.playerTeam=None

    def set_my_team(self, team: PokeTeam) -> None:
        """
           Function that sets the team that will be fighting through the tower.


           Parameters:
           ----------
           self : used to access variables that belong to the class.
           team: PokeTeam --> team that used to battle through the tower

           Returns:
           --------
           *None


           Complexity:
           ----------
           Best-case : O(1)
           Worst-case : O(1)

        """

        self.playerTeam=team

    def generate_teams(self, n: int) -> None:
        """
           Function that generates n teams that will be used for the battle tower.


           Parameters:
           ----------
           self : used to access variables that belong to the class.
           n: int --> number of teams to generate for the tower

           Returns:
           --------
           *None

           Complexity:
           ----------
           Best-case : O(1)
           Worst-case : O(n)

        """
        if type(n)!=int:
            raise ValueError
        # create a circular queue to store the teams
        self.towerTeams=CircularQueue(n)

        # loop n times to create the teams and store it into the queue
        for loopTimes in range(n):
            pokeTeamTower=PokeTeam.random_team(f"Team {n}",RandomGen.randint(0,1))
            pokeTeamTower.pokeTeamLives=RandomGen.randint(2,10)
            self.towerTeams.append(pokeTeamTower)

    def __iter__(self):
        """
          Function that return an object of BattleTowerIterator


          Parameters:
          ----------
          self : used to access variables that belong to the class.

          Returns:
          --------
          returns an object of BattleTowerIterator

          Complexity:
          ----------
          Best-case : O(1)
          Worst-case : O(1)

       """
        return BattleTowerIterator(self.towerTeams,self.playerTeam,self.battleArena)

class BattleTowerIterator:
    """
        A class used to represent the iterator of battle tower.

        Attributes:
        __________
        queuePokeTeamTower: PokeTeam --> The tower teams
        playerPokeTeam: PokeTeam: --> Player team that used to battle through the tower
        battleArena: battle --> used for actual battle
        playerLoseBoolean: boolean  --> indicates the win or lose of the player's team

    """
    def __init__(self,queuePokeTeam,playerPokeTeam,battleArena):
        """
           Function that instantiate the BattleTowerIterator.

           Parameters:
           ----------
           self : used to access variables that belong to the class.
           queuePokeTeamTower: PokeTeam --> The tower teams
           playerPokeTeam: PokeTeam: --> Player team that used to battle through the tower
           battleArena: battle --> used for actual battle

           Returns:
           --------
           *None

           Complexity:
           ----------
           Best-case : O(1)
           Worst-case : O(1)

        """
        self.queuePokeTeamTower=queuePokeTeam
        self.playerPokeTeam=playerPokeTeam
        self.battleArena=battleArena
        self.playerLoseBoolean=False

    def __iter__(self):
        """
          Function that return an object with a __next__ method.

          Parameters:
          ----------
          self : used to access variables that belong to the class.

          Returns:
          --------
          Returns self

          Complexity:
          ----------
          Best-case : O(1)
          Worst-case : O(1)

        """
        return self

    def __next__(self):
        """
          Function that perform one battle in the tower and return a tuple

          Parameters:
          ----------
          self : used to access variables that belong to the class.

          Returns:
          --------
          Returns a tuple containing the result,playerteam  after the battle,tower team after the battle,remaining lives of the tower team

          Complexity:
          ----------
          Best-case : O(1)
          Worst-case : O(B)

        """
        tupleResult=None
        # if the tower teams is not empty and player team have not lose
        # take the first team in the queue and bttle with the player team
        if len(self.queuePokeTeamTower)>0 and self.playerLoseBoolean==False:
            towerPokemonTeam=self.queuePokeTeamTower.serve()
            battleResult=self.battleArena.battle(self.playerPokeTeam,towerPokemonTeam)
            # if the plyaer team wins
            # deduct the lives of the tower team and regenerate the team of player team

            if battleResult==1:
                towerPokemonTeam.pokeTeamLives-=1
                self.playerPokeTeam.regenerate_team()
                # if the tower team still have lives remaining append it back to the queue

                if towerPokemonTeam.pokeTeamLives>0:
                    self.queuePokeTeamTower.append(towerPokemonTeam)

                # store the result into the tuple
                tupleResult=(battleResult,self.playerPokeTeam,towerPokemonTeam,towerPokemonTeam.pokeTeamLives)
                return tupleResult
            # else if the tower team wins,
            # store the result into the tuple and set the player team to lose
            elif battleResult==2:
                tupleResult = (battleResult, self.playerPokeTeam, towerPokemonTeam, towerPokemonTeam.pokeTeamLives)
                self.playerLoseBoolean=True
                return tupleResult
        # else: if the tower team is empty or the player team has lost, stop iteration
        else:
            raise StopIteration



    def avoid_duplicates(self):
        """
          Function that removes all currently alive trainers from the battle tower which have multiple pokemon with the same types.


          Parameters:
          ----------
          self : used to access variables that belong to the class.

          Returns:
          --------
          *None

          Complexity:
          ----------
          Best-case : O(1)
          Worst-case : O(N * P)

        """
        # loop with the range of number of poke team in the team tower
        for looptimes in range(len(self.queuePokeTeamTower)):
            # create the variables to store the number of pokemon for each type
            fireType=0
            grassType=0
            waterType=0
            ghostType=0
            normalType=0
            # serve the poketeam from the queue
            pokeTeam=self.queuePokeTeamTower.serve()
            # iterate through the range of each poke team
            for looptime in range(pokeTeam.getTeamSize()):
                # retrive pokemon from the team
                # check the pokemon type and increase the variables that stores the number of pokemon for each type
                pokemon=pokeTeam.retrieve_pokemon()
                if pokemon.pokemonType==0:
                    fireType+=1
                elif pokemon.pokemonType==1:
                    grassType+=1

                elif pokemon.pokemonType==2:
                    waterType+=1

                elif pokemon.pokemonType==3:
                    ghostType+=1

                elif pokemon.pokemonType==4:
                    normalType+=1
            # regenerate poke team
            pokeTeam.regenerate_team()

            # if there is no mutiple same type pokemon in the team, append it back into the team tower
            if fireType<=1 and grassType<=1 and waterType<=1 and ghostType<=1 and normalType<=1:
                self.queuePokeTeamTower.append(pokeTeam)


    def sort_by_lives(self):
        # 1054
        raise NotImplementedError()