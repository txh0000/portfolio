from __future__ import annotations

import enum

"""
Poke team is a class which uses different types of abstract data type to store pokemons.
"""
__author__ = "Scaffold by Jackson Goerner, Code by Lim Jun Kee, Lim Wei En, Heng Zi Ying, Toh Xi Heng"

from enum import Enum, auto
from pokemon_base import PokemonBase
from queue_adt import *
from pokemon import *
from random_gen import *
from array_sorted_list import *


class Action(Enum):
    ATTACK = auto()
    SWAP = auto()
    HEAL = auto()
    SPECIAL = auto()


class Criterion(Enum):
    SPD = auto()
    HP = auto()
    LV = auto()
    DEF = auto()


class PokeTeam:
    """
        A class used to represent a Pokemon team.

        Attributes:
        __________
        teamName: str --> Name of Pokemon team.
        teamNumbers: list --> A list to specify how many charmanders, bulbasaurs, squirtles, gastlys and eevees the team has respectively
        battleMode: int --> Battle mode of the team.
        aiType: Enum --> AI mode of the Pokemon team.
        sortListBoolean: boolean --> a boolean value to determine the ways of sorting for the list (ascending or descending)
        healTimes: int --> Number of heal times for each Pokemon team.
        pokeTeam: ADT --> An ADT contains the instance of Pokemon.
        criterion: Enum

    """
    class AI(Enum):
        ALWAYS_ATTACK = auto()
        SWAP_ON_SUPER_EFFECTIVE = auto()
        RANDOM = auto()
        USER_INPUT = auto()

    def __init__(self, team_name: str, team_numbers: list[int], battle_mode: int, ai_type: PokeTeam.AI, criterion=None,
                 criterion_value=None, pokeTeamLive=None) -> None:
        """
        Function that instantiate the Pokemon Team.

        Parameters:
        ----------
        self : used to access variables that belong to the class.
        teamName: str --> Name of Pokemon team.
        teamNumbers: list --> A list to specify how many charmanders, bulbasaurs, squirtles, gastlys and eevees the team has respectively.
        battleMode: int --> Battle mode of the team.
        aiType: Enum --> AI mode of the Pokemon team.
        criterion: Enum

        Complexity:
        ----------
        Best-case : O(nm)
        Worst-case : O(nm)

        """
        if type(team_name)!=str or type(team_numbers)!=list or type(battle_mode)!=int :
            raise ValueError

        self.teamName = team_name
        self.teamNumbers = team_numbers
        self.battleMode = battle_mode
        self.aiType = ai_type
        self.sortListBoolean = True
        self.healTimes = 0
        self.pokeTeam = None
        self.pokeTeamLives = pokeTeamLive

        # if the battle mode is 0 or 1, create the Poke team with createPokeTeam() function
        # and sort it by the Pokedex order
        if self.battleMode == 0 or self.battleMode == 1:
            self.createPokeTeam(self.teamNumbers, self.battleMode)

        # if the battle mode is 2, create the Poke team with createSortPokemonTeam() function
        elif self.battleMode == 2:
            self.criterion = criterion
            if self.criterion == None:
                raise Exception("None criterion")
            else:
                self.createSortPokemonTeam(self.teamNumbers)



    @classmethod
    def random_team(cls, team_name: str, battle_mode: int, team_size=None, ai_mode=None, **kwargs):
        """
        Function that creates a random Pokemon team.

        Parameters
        ----------
        self : used to access variables that belong to the class
        teamName: str --> Name of Pokemon team.
        battleMode: int --> Battle mode of the team.
        team_size: int --> Size of the team to be formed.
        ai_mode : Enum --> AI mode of the Pokemon team.
        **kwargs --> used to pass a keyworded, variable-length argument list

        Returns:
        --------
        Return a Pokemon team.

        Complexity:
        ----------
        Best-case : O(1)
        Worst-case : O(1)

        """
        # generate a random team size if no team size was given
        if team_size == None:
            team_size = RandomGen.randint(3, 6)
        # set the AI mode to random if AI mode is None
        if ai_mode == None:
            ai_mode = PokeTeam.AI.RANDOM
        # create temporary storage
        tempSortList = ArraySortedList(6)
        tempArrayR = ArrayR(6)
        teamNumber = []
        tempSortList.add(ListItem("Zero", 0), False)
        tempSortList.add(ListItem("TeamSize", team_size), False)

        # generate 4 random number nand store it in the temporary array sorted list
        for generateTimes in range(4):
            tempSortList.add(ListItem("RandomNumber", RandomGen.randint(0, team_size)), False)

        # store the 6 numbers into  teamporary array
        for i in range(len(tempSortList)):
            tempArrayR[i] = tempSortList[i].key

        teamNumber = [None] * (len(tempArrayR) - 1)
        # form the team number by subtracting each adjacent element in the temporary array
        for i in range(1, len(tempArrayR)):
            adjacentValue = tempArrayR[i] - tempArrayR[i - 1]
            teamNumber[i - 1] = adjacentValue

        # create the Poke team according to their battle mode
        if battle_mode == 2:

            return PokeTeam(team_name, teamNumber, battle_mode, ai_mode, kwargs['criterion'])

        else:

            return PokeTeam(team_name, teamNumber, battle_mode, ai_mode)

    def return_pokemon(self, poke: PokemonBase) -> None:
        """
        Function that return the Pokemon to the Poke team according to their battle mode

        Parameters
        ----------
        self : used to access variables that belong to the class
        poke: PokemonBase --> Pokemon to be return to its team

        Returns:
        --------
        *None

        Complexity:
        ----------
        Best-case : O(1)
        Worst-case : O(n)

        """
        # return them only if they are not fainted
        if poke.is_fainted() == False:
            # battle mode 0 (Stack): 0 returns the pokemon to the front of the team, having everyone shuffle down.
            if self.battleMode == 0:
                self.pokeTeam.push(poke)

            # battle mode 1 (CircularQueue): returns the pokemon to the end of the team, having everyone stay
            # where they are.
            elif self.battleMode == 1:
                self.pokeTeam.append(poke)

            # battle mode 2 (Array Sorted List): returns the pokemon to their correct position within the ordering of the team.
            elif self.battleMode == 2:
                self.sortAdd(ListItem(poke, self.criterionManager(poke, self.criterion.value)), self.sortListBoolean)

    def retrieve_pokemon(self) -> PokemonBase | None:
        """
        Function that retrieve a Pokemon from the Poke team according to their battle mode

        Parameters
        ----------
        self : used to access variables that belong to the class

        Returns:
        --------
        Return the Pokemon that retrieve from its team

         Complexity:
        ----------
        Best-case : O(1)
        Worst-case : O(1)

        """
        # return None if the team is empty
        if self.is_empty():
            return None
        # else: if the team is not empty
        else:
            # battle mode 0 (Stack) : retrieves the first pokemon in the team, having everyone shuffle up
            # After retrieving set the Status to "free" and return the pokemon that has been retrieved
            if self.battleMode == 0:
                returnPokemon = self.pokeTeam.pop()
                returnPokemon.pokemonStatus = "free"
                return returnPokemon
            # battle mode 1 (CircularQueue): retrieves the first pokemon in the team, having everyone shuffle up
            # After retrieving set the Status to "free" and return the pokemon that has been retrieved
            elif self.battleMode == 1:
                returnPokemon = self.pokeTeam.serve()
                returnPokemon.pokemonStatus = "free"
                return returnPokemon

            # battle mode 2 (Array Sorted List): retrieves the first pokemon in the team, having everyone shuffle up
            # After retrieving set the Status to "free" and return the pokemon that has been retrieved
            elif self.battleMode == 2:
                returnPokemon = self.pokeTeam.delete_at_index(0).value
                returnPokemon.pokemonStatus = "free"

                return returnPokemon

    def special(self):
        """
        Function that the special operation on the team according to their battle mode

        Parameters
        ----------
        self : used to access variables that belong to the class

        Returns:
        --------
        *None

        Complexity:
        ----------
        Best-case : O(n)
        Worst-case : O(n)
        """
        # battle mode 0 (Stack): swaps the first and last pokemon on the team.
        if self.battleMode == 0:
            #if the length of pokemon is greater or equal to 3
            if len(self.pokeTeam) >= 3:
                #pop and store the first pokemon in a variable
                firstItem = self.pokeTeam.pop()
                #creates a temporary stack
                tempStack = ArrayStack(len(self.pokeTeam) - 1)
                #loop through the original stack and push the remaining pokemon except the last pokemon into the temporary stack
                for i in range(len(self.pokeTeam) - 1):
                    tempStack.push(self.pokeTeam.pop())
                #pop and store the lastt pokemon in a variable
                lastItem = self.pokeTeam.pop()
                #after that the original stack will be empty
                #we can start to push the element into it
                #step1: push the first pokemon
                self.pokeTeam.push(firstItem)
                #step2:use for loop to push the pokemon from teamporary stack to the ori stack
                for i in range(len(tempStack)):
                    self.pokeTeam.push(tempStack.pop())
                #step3: push the last pokemon
                self.pokeTeam.push(lastItem)

            # if the number of Pokemon in the team is equal to 2
            # pop and store the first and last pokemon in the stack
            # push the last pokemon in to the stack first and push the first pokemon in to the stack secondly
            elif len(self.pokeTeam) == 2:
                firstItem = self.pokeTeam.pop()
                lastItem = self.pokeTeam.pop()
                self.pokeTeam.push(firstItem)
                self.pokeTeam.push(lastItem)


        # battle mode 1 (CircularQueue): swaps the first and second halves of the team and reverses the order of the
        # previously front half of the team.
        elif self.battleMode == 1:
            # check the number of pokemon to be swap in the first half using integer division the total number of Pokemon in the team  by 2
            numOfPokemonSwap = len(self.pokeTeam) // 2
            # if the number of Pokemon in the team is greater than 3
            if len(self.pokeTeam) > 3:
                tempStack = ArrayStack(numOfPokemonSwap)
                # store the first half pokemon into a temporary arraystack by serving the pokemon in the queue
                for serveTimes in range(numOfPokemonSwap):
                    tempStack.push(self.pokeTeam.serve())
                 # append it into the back of the queue by popping the temporary arraystack
                for appendTimes in range(numOfPokemonSwap):
                    self.pokeTeam.append(tempStack.pop())
            # if the number of Pokemon in the team is equal to 3
            elif len(self.pokeTeam) == 3:
                # store the first 2 pokemon into two variables seperately and
                # append it back into the queue accordingly
                pokemonA = self.pokeTeam.serve()
                pokemonB = self.pokeTeam.serve()
                self.pokeTeam.append(pokemonB)
                self.pokeTeam.append(pokemonA)
            # if the number of Pokemon in the team is equal to 2
            # serve the first pokemon in the queue and append it to the back of the queue
            elif len(self.pokeTeam) == 2:
                pokemonA = self.pokeTeam.serve()
                self.pokeTeam.append(pokemonA)

        # battle mode 2 (Array Sorted List): reverse the sorting order of the team according to its hp
        elif self.battleMode == 2:
            # store the pokemon into a temporary list
            tempList = [None] * len(self.pokeTeam)
            for i in range(len(self.pokeTeam)):
                tempList[i] = self.pokeTeam[i]
            # reset the team
            self.reverseSort()
            self.pokeTeam.reset()
            self.pokeTeam = ArraySortedList(len(tempList))
            # append the element in the temporary list in reverse order
            for item in tempList:
                self.sortAdd(ListItem(item.value, item.key), self.sortListBoolean)

    def regenerate_team(self):
        """
        Function that regenerate the team from the same battle numbers. Used to make a team ready for another battle.

        Parameters
        ----------
        self : used to access variables that belong to the class

        Returns:
        --------
        *None

        Complexity:
        ----------
        Best-case : O(nm)
        Worst-case : O(nm)

        """
        if self.battleMode == 0 or self.battleMode == 1:
            self.createPokeTeam(self.teamNumbers, self.battleMode)
        #else:battlemode==2
        else:
            self.sortListBoolean = True
            self.createSortPokemonTeam(self.teamNumbers)

    def __str__(self):
        """
        Function that  return a valid string representation of the team according to its battle mode.

        Parameters
        ----------
        self : used to access variables that belong to the class

        Returns:
        --------
        Return a valid string representation of the team

        Complexity:
        ----------
        Best-case : O(1)
        Worst-case : O(n)

        """

        if self.battleMode == 0:
            return f"{self.teamName} ({self.battleMode}): {self.pokeTeam}"


        elif self.battleMode == 1:
            return f"{self.teamName} ({self.battleMode}): {self.pokeTeam}"


        elif self.battleMode == 2:
            tempList = [None] * len(self.pokeTeam)

            for i in range(len(self.pokeTeam)):
                tempList[i] = self.pokeTeam[i].value

            pokemonStr = ""
            for i in range(len(tempList)):
                if i != (len(tempList) - 1):
                    pokemonStr += f"{tempList[i]}, "

                else:
                    pokemonStr += f"{tempList[i]}"

            return f"{self.teamName} ({self.battleMode}): [{pokemonStr}]"

    def is_empty(self):
        """
        Function that checks whether the team is empty.

        Parameters
        ----------
        self : used to access variables that belong to the class

        Returns:
        --------
        Returns a boolean value that indicates whether the string is empty

        Complexity:
        ----------
        Best-case : O(1)
        Worst-case : O(1)

        """
        # check if the team length is equal to 0
        if len(self.pokeTeam) == 0:
            return True
        else:
            return False

    def choose_battle_option(self, my_pokemon: PokemonBase, their_pokemon: PokemonBase) -> Action:
        """
        Function that decides on an action depending on the pokemon currently in the field.

        Parameters
        ----------
        self : used to access variables that belong to the class
        my_pokemon: PokemonBase --> A pokemon from the first team
        their_pokemon: PokemonBase --> A pokemon from the other team

        Returns:
        --------
        Returns an Action

        Complexity:
        ----------
        Best-case : O(1)
        Worst-case : O(1)

        """
        returnAction = None
        # check the heal times and set the option for list action
        # if the healTimes is greater or equal to 3, no HEAL option will be given in the lsit
        if self.healTimes < 3:
            tempListAction = [Action.ATTACK, Action.SWAP, Action.HEAL, Action.SPECIAL]
        else:
            tempListAction = [Action.ATTACK, Action.SWAP, Action.SPECIAL]

        # when AI mode is Random : Will randomly select a valid action.
        if self.aiType == PokeTeam.AI.RANDOM:

            returnAction = tempListAction[RandomGen.randint(0, len(tempListAction) - 1)]
        # when AI mode is User Input : : Will prompt the user for some input.
        elif self.aiType == PokeTeam.AI.USER_INPUT:
            print("A [ATTACK], P [POKEMON], H [HEAL], S [SPECIAL]")
            userInput = input("Your Move :")
            if userInput == "A":
                returnAction = Action.ATTACK
            elif userInput == "P":
                returnAction = Action.SWAP
            elif userInput == "H":
                returnAction = Action.HEAL
            elif userInput == "S":
                returnAction = Action.SPECIAL

        # when AI mode is Swap On Super Effective :: Always select swap if the opposing pokemon's
        # attacks are super-effective (will have effective damage larger or equal to 1.5 times their attack stat).
        # Will otherwise attack.
        elif self.aiType == PokeTeam.AI.SWAP_ON_SUPER_EFFECTIVE:
            attackMultiplier = their_pokemon.getAttackMultiplier(my_pokemon)
            if attackMultiplier >= 1.5:
                returnAction = Action.SWAP

            else:
                returnAction = Action.ATTACK

        else:
            returnAction = Action.ATTACK

        # increase the heal time of the team if the action choosen is Heal
        if returnAction == Action.HEAL:
            self.healTimes += 1
            return returnAction
        else:
            # raise exception if no action is choosen
            if returnAction == None:
                raise Exception("no return Action")
            return returnAction

    @classmethod
    def leaderboard_team(cls):
        raise NotImplementedError()

    def createPokeTeam(self, teamNumberList, battleMode):
        """
        This function use to create the pokemon team where their battle mode is 0 or 1.

        Parameters
        ----------
        self : used to access variables that belong to the class
        teamNumberList: list --> A list to specify how many charmanders, bulbasaurs, squirtles, gastlys and eevees the team has respectively
        battleMode: int --> the battle mode of the team

        Returns:
        --------
        *None

        Complexity:
        ----------
        Best-case : O(nm)
        Worst-case : O(nm)

        """
        newcopyTeamNumberList = teamNumberList.copy()
        # create a ArraySatck ADT to store the pokemon if the battle mode is 0
        if battleMode == 0:
            self.pokeTeam = ArrayStack(sum(newcopyTeamNumberList))
            # since it is a stack, we will be appending the the stack by pushing the pokemon in the order of
            # eevees, gastlys, squirtles, bulbasaurs, charmanders
            # thus we need to reverse the teamNumberList
            newcopyTeamNumberList.reverse()

        # create a CircularQueue ADT to store the pokemon if the battle mode is 1
        elif battleMode == 1:
            self.pokeTeam = CircularQueue(sum(newcopyTeamNumberList))
        # use nested for loop to append the related Pokemon into the ADT depending on the teamNumberList
        # i represents the index of teamNumber, and each index represents different type of Pokemon
        for i in range(len(newcopyTeamNumberList)):
            # for loop to iterate through the numbers for each type of pokemon to add into the team
            for appendTime in range(newcopyTeamNumberList[i]):
                if i == 0:
                    if battleMode == 1:
                        charmanderObj = Charmander()
                        self.pokeTeam.append(charmanderObj)

                    elif battleMode == 0:
                        eeveeObj = Eevee()
                        self.pokeTeam.push(eeveeObj)

                elif i == 1:
                    if battleMode == 1:
                        bulbasaurObj = Bulbasaur()
                        self.pokeTeam.append(bulbasaurObj)

                    elif battleMode == 0:
                        gastlyObj = Gastly()
                        self.pokeTeam.push(gastlyObj)


                elif i == 2:
                    if battleMode == 1:
                        squirtleObj = Squirtle()
                        self.pokeTeam.append(squirtleObj)

                    elif battleMode == 0:
                        squirtleObj = Squirtle()
                        self.pokeTeam.push(squirtleObj)

                elif i == 3:
                    if battleMode == 1:
                        gastlyObj = Gastly()
                        self.pokeTeam.append(gastlyObj)

                    elif battleMode == 0:
                        bulbasaurObj = Bulbasaur()
                        self.pokeTeam.push(bulbasaurObj)

                elif i == 4:
                    if battleMode == 1:
                        eeveeObj = Eevee()
                        self.pokeTeam.append(eeveeObj)

                    elif battleMode == 0:
                        charmanderObj = Charmander()
                        self.pokeTeam.push(charmanderObj)

    def createSortPokemonTeam(self, teamNumber):
        """
        This function use to create the pokemon team where their battle mode is 2

        Parameters
        ----------
        self : used to access variables that belong to the class
        teamNumber: list --> A list to specify how many charmanders, bulbasaurs, squirtles, gastlys and eevees the team has respectively

        Returns:
        --------
        *None

        Complexity:
        ----------
        Best-case : O(nm)
        Worst-case : O(nm)

        """
        # create an Array Sorted List to store the pokemon
        self.pokeTeam = ArraySortedList(sum(teamNumber))
        # use a nested for loop to append the related Pokemon into the team according to the teamNumber list
        # i represents the index of teamNumber, and each index represents different type of Pokemon
        for i in range(len(teamNumber)):
            # for loop to iterate through the numbers for each type of pokemon to add into the team
            for appendTime in range(teamNumber[i]):
                if i == 0:
                    charmanderObj = Charmander()
                    self.sortAdd(ListItem(charmanderObj, self.criterionManager(charmanderObj, self.criterion.value)),
                                 self.sortListBoolean, True)


                elif i == 1:
                    bulbasaurObj = Bulbasaur()
                    self.sortAdd(ListItem(bulbasaurObj, self.criterionManager(bulbasaurObj, self.criterion.value)),
                                 self.sortListBoolean, True)


                elif i == 2:
                    squirtleObj = Squirtle()
                    self.sortAdd(ListItem(squirtleObj, self.criterionManager(squirtleObj, self.criterion.value)),
                                 self.sortListBoolean, True)



                elif i == 3:
                    gastlyObj = Gastly()
                    self.sortAdd(ListItem(gastlyObj, self.criterionManager(gastlyObj, self.criterion.value)),
                                 self.sortListBoolean, True)


                elif i == 4:
                    eeveeObj = Eevee()
                    self.sortAdd(ListItem(eeveeObj, self.criterionManager(eeveeObj, self.criterion.value)),
                                 self.sortListBoolean, True)

    def criterionManager(self, pokemonObj, criterionNum):
        """
        Function that get the criterion to be used.

        Parameters
        ----------
        self : used to access variables that belong to the class
        pokemonObj: PokemonBase --> Pokemon object
        criterionNum: int --> the value of criterion(Enum)

        Returns:
        --------
        Return the criterion that should be followed.

        Complexity:
        ----------
        Best-case : O(1)
        Worst-case : O(1)

        """
        # store the way to acces each criterion in a list

        listMethod = [pokemonObj.get_speed(), pokemonObj.get_hp(), pokemonObj.get_level(), pokemonObj.get_defence()]
        # since the criterionnum is 1-4 for each of the criterion
        # thus to access the list we have created, we need to minus by 1 to get the index of the list
        return listMethod[criterionNum - 1]

    def sortAdd(self, listItem, sortBoolean, teamCreation=None):
        """
                Function that sort the pokemon team by pokedex order and healthPoint priority everytime a pokemon is added.

                Parameters
                ----------
                self : used to access variables that belong to the class
                listItem: ListItem --> A ListItem object that contain pokemon object as value and its criterion as key.
                sortBoolean: boolean --> A boolean where it decide its sorting order.
                teamCreation:boolean --> A boolean that decide when to sort the pokemon team order.

                Returns:
                --------
                None.

                Complexity:
                ----------
                Best-case : O(1)
                Worst-case : O(1)

        """

        ## To determine hp:9/9 and 9/15.
        hpNotFullConstantFloat = 0.5
        pokemonEvolveFloat = 0.01

        gengarConstantFloat = 0.02

        if teamCreation == True:
            pokemonFloatList = [0.4, 0.3, 0.2, 0.1, 0]

        else:
            pokemonFloatList = [0, 0, 0, 0, 0]
            gengarConstantFloat = 0
            pokemonEvolveFloat = 0
            hpNotFullConstantFloat = 0

        if listItem.value.get_total_hp_lost() == 0:
            hpNotFullConstantFloat = 0

        if listItem.value.can_evolve() == True and listItem.value.get_poke_name() != "Haunter" or listItem.value.get_poke_name() == "Eevee":
            newlistItem = ListItem(listItem.value,
                                   listItem.key + pokemonFloatList[listItem.value.pokemonType] + hpNotFullConstantFloat)
            self.pokeTeam.add(newlistItem, sortBoolean)

        elif listItem.value.can_evolve() == False or listItem.value.get_poke_name() == "Haunter" and listItem.value.get_poke_name() != "Gengar" and listItem.value.get_poke_name() != "Eevee":
            newlistItem = ListItem(listItem.value,
                                   listItem.key + pokemonFloatList[
                                       listItem.value.pokemonType] + pokemonEvolveFloat + hpNotFullConstantFloat)
            self.pokeTeam.add(newlistItem, sortBoolean)

        elif listItem.value.get_poke_name() == "Gengar":
            newlistItem = ListItem(listItem.value, listItem.key + pokemonFloatList[
                listItem.value.pokemonType] + gengarConstantFloat + hpNotFullConstantFloat)
            self.pokeTeam.add(newlistItem, sortBoolean)

    def reverseSort(self):
        """
        Function that will determine whether reverse sort is required

        Parameters
        ----------
        self : used to access variables that belong to the class

        Returns:
        --------
        *None

        Complexity:
        ----------
        Best-case : O(1)
        Worst-case : O(1)

        """
        if self.sortListBoolean == True:
            self.sortListBoolean = False
        else:
            self.sortListBoolean = True

    def getTeamSize(self):
        """
        Function that returns the team size.

        Parameters
        ----------
        self : used to access variables that belong to the class

        Returns:
        --------
        Returns the team size.

        Complexity:
        ----------
        Best-case : O(1)
        Worst-case : O(1)

        """
        return len(self.pokeTeam)

