from __future__ import annotations

"""
Tournament is a class that enables many matches to occur based on the string inputs.
"""
__author__ = "Scaffold by Jackson Goerner, Code by Lim Jun Kee, Lim Wei En, Heng Zi Ying, Toh Xi Heng"

from poke_team import PokeTeam
from battle import Battle
from linked_list import LinkedList
from stack_adt import *

class Tournament:
    """
            A class used to represent tournament.

            Attributes:
            __________
            battleArena: battle --> used for actual battle
            battleModeTeam: int --> used to define battle mode for random pokemon team
            pokeTeamLinkList: LinkList --> A link list that store list that contain 2 pokemon teams and "+"
            tournamentStack: ArrayStack --> An array stack that store the winner pokemon team from the battle
            numberOfMatches: int --> Total matches that this tournament will have
            numberOfBaseMatches: int --> Total of the starting matches of this tournament.
    """

    def __init__(self, battle: Battle|None=None) -> None:
        """
                   Function that instantiate the tournament.

                   Parameters:
                   ----------
                   self : used to access variables that belong to the class.
                   battle|None: battle --> used for actual battle

                   Returns:
                   --------
                   *None

                   Complexity:
                   ----------
                   Best-case : O(1)
                   Worst-case : O(1)

        """
        if battle==None:
            self.battleArena=Battle(verbosity=0)
        else:
            self.battleArena=battle
        self.battleModeTeam=-1#default value
        self.pokeTeamLinkList=LinkedList()
        self.tournamentStack=0
        self.numberOfMatches=0
        self.numberOfBaseMatches=0

    def set_battle_mode(self, battle_mode: int) -> None:
        """
                           Function set the value for battleModeTeam.

                           Parameters:
                           ----------
                           self : used to access variables that belong to the class.
                           battle_mode: int --> battle mode number

                           Returns:
                           --------
                           *None

                           Complexity:
                           ----------
                           Best-case : O(1)
                           Worst-case : O(1)

        """
        self.battleModeTeam=battle_mode

    def is_valid_tournament(self, tournament_str: str) -> bool:
        """
               Function that check whether the tournament_str can be converted to a valid tournament.

               Parameters:
               ----------
               self : used to access variables that belong to the class.
               tournament_str: str --> tournament string format

               Returns:
               --------
               *boolean

               Complexity:
               ----------
               Best-case : O(1)
               Worst-case : O(n)

        """
        tempLinkList = LinkedList()
        tempLinkListB=LinkedList()
        tempStr = ""

        for char in tournament_str:
            if char != "+":
                tempStr += char
            else:
                tempLinkList.append(tempStr)
                tempLinkList.append(char)
                tempStr = ""

        for i in range(len(tempLinkList)):
            if tempLinkList[i] != " " and tempLinkList[i] != "":
                tempLinkListB.append(tempLinkList[i].strip())
        tempStack = ArrayStack(len(tempLinkListB))

        try:
            for i in range(len(tempLinkListB)):
                if tempLinkListB[i]!="+":
                    tempStack.push("randomStr")
                    tempStack.push("randomStr")

                elif tempLinkListB[i]=="+":
                    tempStack.pop()
                    tempStack.pop()
                    tempStack.push("randomStr")

        except:
            return False

        return True







    # def is_balanced_tournament(self, tournament_str: str) -> bool:
    #     # 1054 only
    #     raise NotImplementedError()

    def start_tournament(self, tournament_str: str) -> None:
        """
               Function that process tournament_str and store random generated pokemon team into pokeTeamLinkList based on tournament_str.

               Parameters:
               ----------
               self : used to access variables that belong to the class.
               tournament_str: str --> tournament string format

               Returns:
               --------
               *None

               Complexity:
               ----------
               Best-case : O(1)
               Worst-case : O(n)

        """
        if self.is_valid_tournament(tournament_str)==True:
            tempLinkList = LinkedList()
            tempLinkB=LinkedList()
            tempStr = ""

            for char in tournament_str:
                if char != "+":
                    tempStr += char
                else:
                    tempLinkList.append(tempStr)
                    tempLinkList.append(char)
                    tempStr = ""
            for i in range(len(tempLinkList)):
                if tempLinkList[i] != " " and tempLinkList[i] != "":
                    tempLinkB.append(tempLinkList[i].strip())

            for i in range(len(tempLinkB)):
                if tempLinkB[i]!="+":
                    teamNameList=tempLinkB[i].split(" ")
                    pokemonTeam1=PokeTeam.random_team(teamNameList[0],self.battleModeTeam)
                    pokemonTeam2=PokeTeam.random_team(teamNameList[1],self.battleModeTeam)
                    self.pokeTeamLinkList.append([pokemonTeam1,pokemonTeam2])
                else:
                    self.pokeTeamLinkList.append("+")
                    self.numberOfMatches+=1
            self.tournamentStack=ArrayStack(len(self.pokeTeamLinkList))
            self.numberOfBaseMatches=self.numberOfMatches//2



        else:
            raise ValueError

    def advance_tournament(self) -> tuple[PokeTeam, PokeTeam, int] | None:
        """
               Function that return a tuple which contain 2 PokeTeam and their battle result per function call.

               Parameters:
               ----------
               self : used to access variables that belong to the class.


               Returns:
               --------
               *tuple[PokeTeam, PokeTeam, int]

               Complexity:
               ----------
               Best-case : O(1)
               Worst-case : O(B+P)
               B is the time complexity of running a battle, and P is the number of pokemon in the party.

        """
        if len(self.pokeTeamLinkList)>0:
            linkListValue = self.pokeTeamLinkList.delete_at_index(0)
            if linkListValue != "+":
                pokeTeam1 = linkListValue[0]
                pokeTeam2 = linkListValue[1]
                self.tournamentStack.push(pokeTeam1)
                self.tournamentStack.push(pokeTeam2)
                linkListValue = self.pokeTeamLinkList.delete_at_index(0)

            if linkListValue == "+":
                pokeTeam2 = self.tournamentStack.pop()
                pokeTeam1 = self.tournamentStack.pop()
                battleResult = self.battleArena.battle(pokeTeam1,pokeTeam2)
                tupleResult=(pokeTeam1,pokeTeam2,battleResult)
                if battleResult == 0:
                    raise Exception("is a draw")
                elif battleResult == 1:
                    pokeTeam1.regenerate_team()
                    self.tournamentStack.push(pokeTeam1)
                elif battleResult == 2:
                    pokeTeam2.regenerate_team()
                    self.tournamentStack.push(pokeTeam2)
                return tupleResult
        else:
            return None


    def linked_list_of_games(self) -> LinkedList[tuple[PokeTeam, PokeTeam,list[str]]]:
        """
                       Function that return a tuple which contain 2 PokeTeam and a list contain meta element type.

                       Parameters:
                       ----------
                       self : used to access variables that belong to the class.


                       Returns:
                       --------
                       *tuple[PokeTeam, PokeTeam, list[str]]

                       Complexity:
                       ----------
                       Best-case : O(1)
                       Worst-case : O(M * P)
                       M is the total number of matches played and P is the limit on the number of pokemon per team.

        """
        l = LinkedList()
        tempStack=ArrayStack(self.numberOfMatches)

        loopTimes=0
        while True:
            metaElementList=[]
            res = self.advance_tournament()
            if res is None:
                break
            if loopTimes<self.numberOfBaseMatches or loopTimes==self.numberOfMatches-2:
                if res[2]==1:
                    tempStack.push(res[1])
                else:
                    tempStack.push(res[0])

            else:
                for i in range(5):
                    if res[0].teamNumbers[i]==0 and res[1].teamNumbers[i]==0:
                        team2Defeated=tempStack.pop()
                        team1Defeated=tempStack.pop()
                        if team1Defeated.teamNumbers[i]>=1 or team2Defeated.teamNumbers[i]>=1:
                            if i==0:
                                metaElementList=['FIRE']
                            elif i==1:
                                metaElementList=['GRASS']

                            elif i==2:
                                metaElementList=['WATER']

                            elif i==3:
                                metaElementList=['GHOST']

                            elif i==4:
                                metaElementList=['NORMAL']

                if res[2] == 1:
                    tempStack.push(res[1])
                else:
                    tempStack.push(res[0])



            l.insert(0, (res[0], res[1],metaElementList))
            #metaList
            loopTimes+=1

        return l

    def linked_list_with_metas(self) -> LinkedList[tuple[PokeTeam, PokeTeam, list[str]]]:
        """
                               Function that return a tuple which contain 2 PokeTeam and a list contain meta element type by calling linked_list_of_games() method.

                               Parameters:
                               ----------
                               self : used to access variables that belong to the class.


                               Returns:
                               --------
                               *tuple[PokeTeam, PokeTeam, list[str]]

                               Complexity:
                               ----------
                               Best-case : O(1)
                               Worst-case : O(M * P)
                               M is the total number of matches played and P is the limit on the number of pokemon per team.

            """
        return self.linked_list_of_games()

    # def flip_tournament(self, tournament_list: LinkedList[tuple[PokeTeam, PokeTeam]], team1: PokeTeam, team2: PokeTeam) -> None:
    #     # 1054
    #     raise NotImplementedError()

#
# if __name__ == "__main__":
#     a=Tournament(Battle(verbosity=0))
#     b="Roark Gardenia + Maylene Crasher_Wake + + + Fantina Byron + Candice Volkner + + +"
#     c="Roark Gardenia + Maylene Crasher_Wake + Fantina Byron + + + Candice Volkner + +"
#     print(a.is_valid_tournament(b))
#     print(a.is_valid_tournament(c))
#     a.start_tournament("Roark Gardenia + Maylene Crasher_Wake + Fantina Byron + + + Candice Volkner + +")
