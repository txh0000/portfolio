"""
Battle is a class that enables two poke teams to battle.
"""
__author__ = "Scaffold by Jackson Goerner, Code by Lim Jun Kee, Lim Wei En, Heng Zi Ying, Toh Xi Heng"

from random_gen import RandomGen
from poke_team import Action, PokeTeam, Criterion
from print_screen import print_game_screen


class Battle:
    """
       A class used to represent the battle of Pokemon team.

       Attributes:
       __________
       verbosity: int

    """
    def __init__(self, verbosity=0) -> None:
        """
        Function that instantiate the Pokemon Team.

        Parameters:
        ----------
        self : used to access variables that belong to the class.
        verbosity: int

        Complexity:
        ----------
        Best-case : O(1)
        Worst-case : O(1)

        """
        self.verbosity = verbosity

    def battle(self, team1: PokeTeam, team2: PokeTeam) -> int:
        """
        Function that Performs the battle between team1 and team2 and return the result.

        Parameters
        ----------
        self : used to access variables that belong to the class
        team1: PokeTeam --> team for battle
        team2: PokeTeam --> team for battle

        Returns:
        --------
        Returns the result after battling.
        Return 0 when the result is draw.
        Return 1 when the team1 wins.
        Return 2 when the team2 wins.

        Complexity:
        ----------
        Best-case : O(n)
        Worst-case : O(n)

        """
        self.team1=team1
        self.team2=team2
        # retrieve the pokemon from each team for battle
        poke1=self.team1.retrieve_pokemon()
        poke2=self.team2.retrieve_pokemon()
        # while the both of the Pokemon is not None, means that there are pokemon can battle
        while poke1!=None and poke2!=None:
            # get the action for each team
            team1Action=self.team1.choose_battle_option(poke1,poke2)
            team2Action=self.team2.choose_battle_option(poke2,poke1)

            print(f"team1Action {team1Action},team1 healtime{self.team1.healTimes}")
            print(f"team2Action {team2Action},team2 healtime{self.team2.healTimes}")
            print(f"team1{self.team1}")
            print(f"team2{self.team2}")



            print_game_screen(poke1.get_poke_name(),poke2.get_poke_name(),poke1.currentHealthPoint,poke1.maxHealthPoint,poke2.currentHealthPoint,poke2.maxHealthPoint,poke1.get_level(),poke2.get_level(),poke1.pokemonStatus,poke2.pokemonStatus,self.team1.getTeamSize()+1,self.team2.getTeamSize()+1)
            # if the action for team1 is SWAP
            # return the pokemon to the team and retrieve a new pokemon from team1
            if team1Action==Action.SWAP:
                print(f"{self.team1} use swapped on {poke1}")
                self.team1.return_pokemon(poke1)
                poke1=self.team1.retrieve_pokemon()
                print(f"{self.team1} get {poke1}")
            # if the action for team2 is SWAP
            # return the pokemon to the team and retrieve a new pokemon from team2
            if team2Action==Action.SWAP:
                print(f"{self.team2} use swapped on {poke2}")
                self.team2.return_pokemon(poke2)
                poke2=self.team2.retrieve_pokemon()
                print(f"{self.team2} get {poke2}")

            # if the action for team1 is SPECIAL
            # return the pokemon to the team
            # do a special action to the team and retrieve a new pokemon
            if team1Action==Action.SPECIAL:
                self.team1.return_pokemon(poke1)
                print(f"{self.team1} use special on {poke1}")
                self.team1.special()
                poke1=self.team1.retrieve_pokemon()
                print(f"{self.team1} get {poke1}")

            # if the action for team2 is SPECIAL
            # return the pokemon to the team
            # do a special action to the team and retrieve a new pokemon
            if team2Action==Action.SPECIAL:
                self.team2.return_pokemon(poke2)
                print(f"{self.team2} use special on {poke2}")
                self.team2.special()
                print(f"{self.team2} team2 after special,adada")
                poke2=self.team2.retrieve_pokemon()
                print(f"{self.team2} get {poke2}")

            # if the  action for team1 is HEAL
            if team1Action==Action.HEAL:
                # check whether the team heal times for team1 is smaller than 3, if yes team1 loses the battle,team2 wins
                if self.team1.healTimes>3:
                    return 2
                #else:heal the pokemon
                else:
                    print(f"{poke1} use heal")
                    poke1.heal()

            # if the  action for team2 is HEAL
            if team2Action==Action.HEAL:
                # check whether the team heal times for team2 is smaller than 3, if yes team2 loses the battle,team1 wins
                if self.team2.healTimes>3:
                    return 1
                # else:heal the pokemon
                else:
                    print(f"{poke2} use heal")
                    poke2.heal()

            # if the action for both teams are ATTACK
            if team1Action==Action.ATTACK and team2Action==Action.ATTACK:
                # determine which pokemon is faster, the fastest will attacks first
                # if poke1 is faster than poke 2
                # then poke1 attack poke2 first
                if poke1.get_speed()>poke2.get_speed():
                    print(f"poke1 speed{poke1.get_speed()} poke2 speed {poke2.get_speed()}")
                    print(f"Poke 1 {poke1} attack Poke2 {poke2}",end=" ")
                    poke1.attack(poke2)
                    print(f"Result {poke1}, {poke2}")

                    # if poke2 is not fainted after the attack
                    # it will attack back poke1
                    if poke2.is_fainted()==False:
                        print(f"{poke2} attacks {poke1}", end=" ")
                        poke2.attack(poke1)
                        print(f"Result {poke2}, {poke1}")

                # if the speed of two pokemon are the same
                # poke1 will attack poke2 first, the poke2 will attack back poke1 continuosly
                elif poke1.get_speed()==poke2.get_speed():
                    print(f"Poke 1 {poke1} attack Poke2 {poke2}", end=" ")
                    poke1.attack(poke2)
                    print(f"Result {poke1}, {poke2}", end=" ")

                    print(f"Poke 2 {poke2} attack Poke1 {poke1}", end=" ")
                    poke2.attack(poke1)
                    print(f"Result {poke2}, {poke1}")

                # else: if the speed of poke2 is faster than poke1
                # poke2 attack poke 1 first
                else:
                    print(f"Poke 2 {poke2} attack {poke1}",end=" ")
                    poke2.attack(poke1)
                    print(f"Result {poke2} {poke1}")

                    # if poke1 is not fainted after the attack
                    # it will attack back poke2
                    if poke1.is_fainted()==False:
                        print(f"Poke 1 {poke1} attack {poke2}", end=" ")
                        poke1.attack(poke2)
                        print(f"Result {poke1} {poke2}")

            # if the action for team1 is ATTACK
            # poke1 attack poke2
            if team1Action==Action.ATTACK and team2Action!=Action.ATTACK:
                print(f"{poke1} attacks {poke2}",end=" ")
                poke1.attack(poke2)
                print(f"Result {poke1} , {poke2}")

            # if the action for team2 is ATTACK
            # poke2 attack poke1
            if team2Action==Action.ATTACK and team1Action!=Action.ATTACK:
                print(f"{poke2} attacks {poke1}",end=" ")
                poke2.attack(poke1)
                print(f"Result {poke2} , {poke1}")



            #check the status of poke1 and poke2
            # if both of the pokemon are not fainted, both lose 1 hp
            if poke1.is_fainted()==False and poke2.is_fainted()==False:
                poke1.lose_hp(1)
                poke2.lose_hp(1)
            #if poke1 is fainted and poke2 is not fainted
            #then poke2 level up
            if poke1.is_fainted()==True and poke2.is_fainted()==False:
                poke2.level_up()
            # if poke2 is fainted and poke1 is not fainted
            # then poke1 level up
            if poke2.is_fainted()==True and poke1.is_fainted()==False:
                poke1.level_up()

            # if one of the pokemon are not fainted
            if poke1.is_fainted()==False or poke2.is_fainted()==False:
                # if both of the pokemon are not fainted
                # check whether both pokemon should evolve, if yes evolve them
                if poke1.is_fainted()==False and poke2.is_fainted()==False:
                    if poke1.should_evolve()==True:
                        poke1=poke1.get_evolved_version()
                    if poke2.should_evolve()==True:
                        poke2=poke2.get_evolved_version()
                #else if poke1 is not fainted and poke2 is fainted
                # check whether poke1 should evolve, if yes, evolve poke1
                # retrieve new pokemon from team2
                elif poke1.is_fainted()==False and poke2.is_fainted()==True:
                    if poke1.should_evolve()==True:
                        poke1=poke1.get_evolved_version()

                    poke2 = self.team2.retrieve_pokemon()
                    #if no pokemon can be retrive from team2, exit the loop
                    # # if the pokemon is NONE after retrieve means that the team is empty and there is no pokemon to retrieve from the team
                    if poke2 == None:
                        break

                # else if poke1 is fainted and poke2 is not fainted
                # check whether poke2 should evolve, if yes, evolve poke2
                # retrieve new pokemon from team1
                elif poke1.is_fainted()==True and poke2.is_fainted()==False:
                    if poke2.should_evolve()==True:
                        poke2=poke2.get_evolved_version()
                    poke1 = self.team1.retrieve_pokemon()
                    # if no pokemon can be retrieve from team1, exit the loop
                    # if the pokemon is NONE after retrieve means that the team is empty and there is no pokemon to retrieve from the team
                    if poke1 == None:
                        break
            # if both pokemon is fainted, retrieve a new pokemon from team1 and team 2 respectively
            if poke1.is_fainted() == True or poke2.is_fainted() == True:
                poke1 = self.team1.retrieve_pokemon()
                poke2 = self.team2.retrieve_pokemon()
                #if one of the team has no pokemon can be retrieved,exit the loop
                # if the pokemon is NONE after retrieve means that the team is empty and there is no pokemon to retrieve from the team
                if poke1==None or poke2==None:
                    break

        #check poke1 and poke2
        #then return the result accordingly
        # if the pokemon is NONE after retrieve means that the team is empty and there is no pokemon to retrieve from the team

        # if the poke1 and poke2 is NONE, the battle is draw
        if poke1==None and poke2==None:
            self.team1.healTimes=0
            self.team2.healTimes=0
            return 0

        # if poke1 is not NONE and poke2 is NONE, team1 wins the battle
        elif poke1!=None and poke2==None:
            #return the alive pokemon to the team
            self.team1.return_pokemon(poke1)
            self.team1.healTimes = 0
            self.team2.healTimes = 0
            return 1

        # if poke1 is NONE and poke2 is not NONE, team2 wins the battle
        elif poke1==None and poke2!=None:
            # return the alive pokemon to the team
            self.team2.return_pokemon(poke2)
            self.team1.healTimes = 0
            self.team2.healTimes = 0
            return 2

