from pokemon import *
from tests.base_test import BaseTest

class TestPokemon(BaseTest):

    def test_venusaur_stats(self):
        """Tests that venusaur levels up and increases all its attributes correctly."""
        v = Venusaur()
        self.assertEqual(v.get_hp(), 21)
        self.assertEqual(v.get_level(), 2)
        self.assertEqual(v.get_attack_damage(), 5)
        self.assertEqual(v.get_speed(), 4)
        self.assertEqual(v.get_defence(), 10)
        v.level_up()
        v.level_up()
        v.level_up()
        self.assertEqual(v.get_hp(), 22)
        self.assertEqual(v.get_level(), 5)
        self.assertEqual(v.get_attack_damage(), 5)
        self.assertEqual(v.get_speed(), 5)
        self.assertEqual(v.get_defence(), 10)
        v.lose_hp(5)

        self.assertEqual(str(v), "LV. 5 Venusaur: 17 HP")

    def test_level_up(self):
        """Tests that pokemon levels up correctly."""
        c = Charmander()
        c.level_up()
        self.assertEqual(c.get_total_hp_lost(), 0)
        self.assertEqual(c.get_level(), 2)
        b = Bulbasaur()
        b.level_up()
        self.assertEqual(b.get_total_hp_lost(), 0)
        self.assertEqual(b.get_level(), 2)
        v = Venusaur()
        v.level_up()
        self.assertEqual(v.get_total_hp_lost(), 0)
        self.assertEqual(v.get_level(), 3)

    def test_level_up_get_health(self):
        """Tests that pokemon levels up with the correct health."""
        c =Charmander()
        c.level_up()
        self.assertEqual(c.get_hp(), 10)
        b = Bulbasaur()
        b.level_up()
        self.assertEqual(b.get_hp(), 14)
        s = Squirtle()
        s.level_up()
        self.assertEqual(s.get_hp(), 13)

    def test_level_up_attack_damage(self):
        """Tests that pokemon levels up with the correct attack damage."""
        c =Charmander()
        c.level_up()
        self.assertEqual(c.get_attack_damage(), 8)
        b = Bulbasaur()
        b.level_up()
        self.assertEqual(b.get_attack_damage(), 5)
        s = Squirtle()
        s.level_up()
        self.assertEqual(s.get_attack_damage(), 5)

    def test_level_up_speed(self):
        """Tests that pokemon levels up with the correct speed."""
        c =Charmander()
        c.level_up()
        self.assertEqual(c.get_speed(), 9)
        b = Bulbasaur()
        b.pokemonStatus = "paralysis"
        b.level_up()
        self.assertEqual(b.get_speed(), 4)
        s = Squirtle()
        s.level_up()
        self.assertEqual(s.get_speed(), 7)

    def test_defend(self):
        """Tests that pokemon defending from other pokemons and taken damage correctly."""
        c = Charmander()
        c.defend(3)
        self.assertEqual(c.get_hp(), 8)
        v = Venusaur()
        v.defend(16)
        self.assertEqual(v.get_hp(), 5)
        b = Bulbasaur()
        b.defend(1)
        self.assertEqual(b.get_hp(), 13)

    def test_can_evolve(self):
        """Tests that pokemon return their can_evolve correctly."""
        e = Eevee()
        self.assertEqual(e.can_evolve(), False)
        c = Charmander()
        self.assertEqual(c.can_evolve(), True)
        z = Charizard()
        self.assertEqual(z.can_evolve(), False)

    def test_should_evolve(self):
        """Tests that pokemon return their should_evolve correctly."""
        g = Gastly()
        self.assertEqual(g.should_evolve(), True)
        b = Bulbasaur()
        self.assertEqual(b.should_evolve(), False)
        b.level_up()
        self.assertEqual(b.should_evolve(), True)
        c = Charmander()
        self.assertEqual(c.should_evolve(), False)
        c.level_up()
        self.assertEqual(c.should_evolve(), False)

    def test_get_evolved_version(self):
        """Tests that pokemon getting their evolved version with the the correct hp or if they do not have an evolved
        version. """
        b = Bulbasaur()
        b.level_up()
        b.lose_hp(5)
        v = b.get_evolved_version()
        self.assertEqual(v.get_poke_name(), "Venusaur")
        self.assertEqual(v.get_hp(), 16)
        c = Charizard()
        with self.assertRaises(Exception):
            c.get_evolved_version()
        s = Squirtle()
        s.level_up()
        with self.assertRaises(Exception):
            s.get_evolved_version()