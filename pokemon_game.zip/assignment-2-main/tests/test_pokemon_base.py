from random_gen import RandomGen
from pokemon_base import PokemonBase, PokeType
from pokemon import *
from tests.base_test import BaseTest


class TestPokemonBase(BaseTest):

    def test_cannot_init(self):
        """Tests that we cannot initialise PokemonBase, and that it raises the correct error."""
        self.assertRaises(TypeError, lambda: PokemonBase(30, PokeType.FIRE))

    def test_level(self):
        """Tests that pokemon levels up correctly."""
        e = Eevee()
        self.assertEqual(e.get_level(), 1)
        e.level_up()
        self.assertEqual(e.get_level(), 2)
    
    def test_hp(self):
        """Tests that pokemon loses and heals hp correctly."""
        e = Eevee()
        self.assertEqual(e.get_hp(), 10)
        e.lose_hp(4)
        self.assertEqual(e.get_hp(), 6)
        e.heal()
        self.assertEqual(e.get_hp(), 10)

    def test_status(self):
        """Tests that pokemon gets attack status correctly."""
        RandomGen.set_seed(0)
        e1 = Eevee()
        e2 = Eevee()
        e1.attack(e2)
        # e2 now is confused.
        e2.attack(e1)
        # e2 takes damage in confusion.
        self.assertEqual(e1.get_hp(), 10)

    def test_evolution(self):
        """Tests that pokemon evolves correctly."""
        g = Gastly()
        self.assertEqual(g.can_evolve(), True)
        self.assertEqual(g.should_evolve(), True)
        new_g = g.get_evolved_version()
        self.assertIsInstance(new_g, Haunter)

    def test_get_total_hp_lost(self):
        """Tests that gets the amount of health the pokemon lost correctly."""
        b = Blastoise()
        b.lose_hp(5)
        self.assertEqual(b.get_total_hp_lost(), 5)
        b.lose_hp(4)
        self.assertEqual(b.get_total_hp_lost(), 9)
        b.lose_hp(3)
        self.assertEqual(b.get_total_hp_lost(), 12)
        
    def test_is_fainted(self):
        """Tests that pokemon is taken enough damage and is fainted."""
        b = Blastoise()
        self.assertEqual(b.is_fainted(), False)
        b.lose_hp(20)
        self.assertEqual(b.is_fainted(), False)
        b.lose_hp(1)
        self.assertEqual(b.is_fainted(), True)

    def test_get_speed(self):
        """Tests that get pokemon speed correctly."""
        c = Charizard()
        self.assertEqual(c.get_speed(), 12)
        b = Blastoise()
        self.assertEqual(b.get_speed(), 10)
        v = Venusaur()
        self.assertEqual(v.get_speed(), 4)

    def test_get_attack_damage(self):
        """Tests that gets pokemon damage correctly."""
        c = Charizard()
        self.assertEqual(c.get_attack_damage(), 16)
        b = Blastoise()
        self.assertEqual(b.get_attack_damage(), 9)
        v = Venusaur()
        self.assertEqual(v.get_attack_damage(), 5)

    def test_get_defence(self):
        """Tests that gets pokemon defence correctly."""
        c = Charizard()
        self.assertEqual(c.get_defence(),4)
        b = Blastoise()
        self.assertEqual(b.get_defence(),11)
        v = Venusaur()
        self.assertEqual(v.get_defence(), 10)

    def test_attack(self):
        """Tests that pokemon attacks another pokemon with the correct attack multiplier and status damages."""
        RandomGen.set_seed(0)
        c = Charizard()
        b = Blastoise()
        v = Venusaur()
        self.assertEqual(c.get_hp(),15)
        self.assertEqual(b.get_hp(),21)
        self.assertEqual(c.pokemonStatus, "free")
        self.assertEqual(b.pokemonStatus, "free")
        c.attack(b)
        self.assertEqual(c.get_hp(),15)
        self.assertEqual(b.get_hp(),17)
        self.assertEqual(c.pokemonStatus, "free")
        self.assertEqual(b.pokemonStatus, "burn")
        b.attack(c)
        self.assertEqual(c.get_hp(),-3)
        self.assertEqual(b.get_hp(),16)
        self.assertEqual(c.pokemonStatus, "paralysis")
        self.assertEqual(b.pokemonStatus, "burn")
        v.attack(b)
        self.assertEqual(b.get_hp(), 11)
        self.assertEqual(b.pokemonStatus, "poison")



    def test_get_poke_name(self):
        """Tests that gets pokemon name correctly."""
        c = Charizard()
        self.assertEqual(c.get_poke_name(), "Charizard")
        b = Blastoise()
        self.assertEqual(b.get_poke_name(), "Blastoise")
        v = Venusaur()
        self.assertEqual(v.get_poke_name(), "Venusaur")

    def test_str(self):
        """Tests that pokemon loses and heals hp correctly."""
        c = Charizard()
        self.assertEqual(str(c), "LV. 3 Charizard: 15 HP")
        b = Blastoise()
        self.assertEqual(str(b), "LV. 3 Blastoise: 21 HP")
        v = Venusaur()
        self.assertEqual(str(v), "LV. 2 Venusaur: 21 HP")

    def test_heal(self):
        """Tests that pokemon heals to full hp and has "free" status correctly."""
        c = Charizard()
        c.lose_hp(5)
        c.heal()
        self.assertEqual(c.get_hp(), 15)
        self.assertEqual(c.pokemonStatus, "free")
        b = Blastoise()
        b.lose_hp(5)
        b.heal()
        self.assertEqual(b.get_hp(), 21)
        self.assertEqual(b.pokemonStatus, "free")
        v = Venusaur()
        v.lose_hp(5)
        v.heal()
        self.assertEqual(v.get_hp(), 21)
        self.assertEqual(v.pokemonStatus, "free")  

    def test_get_attack_multiplier(self):
        """Tests that calculates the attack multiplier of pokemons againts other pokemons."""
        c = Charizard()
        v = Venusaur()  
        s = Squirtle()
        mult_1 = c.getAttackMultiplier(v)
        self.assertEqual(mult_1, 2)
        mult_2 = v.getAttackMultiplier(c)
        self.assertEqual(mult_2, 0.5)
        mult_3 = c.getAttackMultiplier(s)
        self.assertEqual(mult_3, 0.5)

