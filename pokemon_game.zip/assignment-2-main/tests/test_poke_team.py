from poke_team import Action, Criterion, PokeTeam
from random_gen import RandomGen
from pokemon import Bulbasaur, Charizard, Charmander, Gastly, Squirtle, Eevee
from tests.base_test import BaseTest

class TestPokeTeam(BaseTest):

    def test_random(self):
        """Test the PokeTeam.random_team method output whether match the desire output"""
        RandomGen.set_seed(123456789)
        t = PokeTeam.random_team("Cynthia", 0)
        pokemon = []
        while not t.is_empty():
            pokemon.append(t.retrieve_pokemon())
        expected_classes = [Squirtle, Gastly, Eevee, Eevee, Eevee, Eevee]
        self.assertEqual(len(pokemon), len(expected_classes))
        for p, e in zip(pokemon, expected_classes):
            self.assertIsInstance(p, e)

    def test_regen_team(self):
        """Test the PokeTeam regenerate_team() method by retrieving all the pokemon then regenerate it. """

        RandomGen.set_seed(123456789)
        t = PokeTeam.random_team("Cynthia", 2, team_size=4, criterion=Criterion.HP)
        # This should end, since all pokemon are fainted, slowly.
        while not t.is_empty():
            p = t.retrieve_pokemon()
            p.lose_hp(1)
            t.return_pokemon(p)
        t.regenerate_team()
        pokemon = []
        while not t.is_empty():
            pokemon.append(t.retrieve_pokemon())
        expected_classes = [Bulbasaur, Eevee, Charmander, Gastly]
        self.assertEqual(len(pokemon), len(expected_classes))
        for p, e in zip(pokemon, expected_classes):
            self.assertIsInstance(p, e)

    def test_battle_option_attack(self):
        """Test the PokeTeam regenerate_team() method will return Action.ATTACK """
        t = PokeTeam("Wallace", [1, 0, 0, 0, 0], 1, PokeTeam.AI.ALWAYS_ATTACK)
        p = t.retrieve_pokemon()
        e = Eevee()
        self.assertEqual(t.choose_battle_option(p, e), Action.ATTACK)

    def test_battle_option_Swap(self):
        """Test the PokeTeam regenerate_team() method will return Action.SWAP """
        t = PokeTeam("Wallace", [1, 0, 0, 0, 0], 1, PokeTeam.AI.SWAP_ON_SUPER_EFFECTIVE)
        p = t.retrieve_pokemon()
        e = Eevee()
        self.assertEqual(t.choose_battle_option(p, e), Action.ATTACK)





    def test_special_mode_0(self):
        """Test whether PokeTeam first element and last element will swap with each other """
        t = PokeTeam("Lance", [1, 1, 1, 1, 1], 0, PokeTeam.AI.SWAP_ON_SUPER_EFFECTIVE)
        # C B S G E
        t.special()
        # E B S G C
        pokemon = []
        while not t.is_empty():
            pokemon.append(t.retrieve_pokemon())
        expected_classes = [Eevee, Bulbasaur, Squirtle, Gastly, Charmander]
        self.assertEqual(len(pokemon), len(expected_classes))
        for p, e in zip(pokemon, expected_classes):
            self.assertIsInstance(p, e)

    def test_special_mode_1(self):
        """Test battle mode 1 special() method will do the expected arrangement """
        t = PokeTeam("Lance", [1, 1, 1, 1, 1], 1, PokeTeam.AI.SWAP_ON_SUPER_EFFECTIVE)
        # C B S G E
        t.special()
        # S G E B C
        pokemon = []
        while not t.is_empty():
            pokemon.append(t.retrieve_pokemon())
        expected_classes = [Squirtle, Gastly, Eevee, Bulbasaur, Charmander]
        self.assertEqual(len(pokemon), len(expected_classes))
        for p, e in zip(pokemon, expected_classes):
            self.assertIsInstance(p, e)

    def test_special_mode_2(self):##self added
        """Test battle mode 2 special() method will do the expected arrangement """
        t = PokeTeam("Lance", [1, 1, 1, 1, 1], 2, PokeTeam.AI.SWAP_ON_SUPER_EFFECTIVE,criterion=Criterion.HP)
        # C B S G E
        t.special()
        # E G S B C
        pokemon=[]
        while not t.is_empty():
            pokemon.append(t.retrieve_pokemon())

        expected_classes = [Gastly,Charmander,Eevee,Squirtle,Bulbasaur]
        self.assertEqual(len(pokemon), len(expected_classes))
        for p, e in zip(pokemon, expected_classes):
            self.assertIsInstance(p, e)

    def test_string(self):
        """Test pokeTeam string output"""
        t = PokeTeam("Dawn", [1, 1, 1, 1, 1], 2, PokeTeam.AI.RANDOM, Criterion.DEF)
        self.assertEqual(str(t), "Dawn (2): [LV. 1 Gastly: 6 HP, LV. 1 Squirtle: 11 HP, LV. 1 Bulbasaur: 13 HP, LV. 1 Eevee: 10 HP, LV. 1 Charmander: 9 HP]")

    def test_string_2(self):
        """Test pokeTeam string output"""
        t = PokeTeam("Aaron", [1, 0, 1, 1, 1], 1, PokeTeam.AI.RANDOM, Criterion.DEF)
        self.assertEqual(str(t), "Aaron (1): [LV. 1 Charmander: 9 HP, LV. 1 Squirtle: 11 HP, LV. 1 Gastly: 6 HP, LV. 1 Eevee: 10 HP]")

    def test_string_3(self):
        """Test pokeTeam string output"""
        t = PokeTeam("Dom", [0, 0, 0, 1, 1], 1, PokeTeam.AI.RANDOM, Criterion.DEF)
        self.assertEqual(str(t), "Dom (1): [LV. 1 Gastly: 6 HP, LV. 1 Eevee: 10 HP]")


    def test_get_team_size_1(self):
        """Test pokeTeam getTeamSize() method"""
        t = PokeTeam("Dawn", [1, 1, 1, 1, 1], 2, PokeTeam.AI.RANDOM, Criterion.DEF)
        self.assertEqual(t.getTeamSize(),5)

    def test_get_team_size_2(self):
        """Test pokeTeam getTeamSize() method"""
        t = PokeTeam("Dawn", [1, 1, 1, 1, 2], 2, PokeTeam.AI.RANDOM, Criterion.DEF)
        self.assertEqual(t.getTeamSize(),6)

    def test_get_team_size_3(self):
        """Test pokeTeam getTeamSize() method"""
        t = PokeTeam("Dawn", [0, 1, 1, 1, 1], 2, PokeTeam.AI.RANDOM, Criterion.DEF)
        self.assertEqual(t.getTeamSize(),4)

    def test_retrieve_pokemon_battlemode0(self):
        """Test pokeTeam battlemode0 retrieve_pokemon() method"""
        t = PokeTeam("Dawn", [1, 1, 1, 1, 1], 0, PokeTeam.AI.RANDOM, Criterion.DEF)
        retrievePokemon=t.retrieve_pokemon()
        c=Charmander()

        self.assertEqual(retrievePokemon.pokemonName,c.pokemonName)

    def test_retrieve_pokemon_battlemode1(self):
        """Test pokeTeam battlemode1 retrieve_pokemon() method"""
        t = PokeTeam("Dawn", [1, 1, 1, 1, 1], 1, PokeTeam.AI.RANDOM, Criterion.DEF)
        retrievePokemon=t.retrieve_pokemon()
        c=Charmander()

        self.assertEqual(retrievePokemon.pokemonName,c.pokemonName)

    def test_retrieve_pokemon_battlemode2(self):
        """Test pokeTeam battlemode2 retrieve_pokemon() method"""
        t = PokeTeam("Dawn", [1, 1, 1, 1, 1], 2, PokeTeam.AI.RANDOM, Criterion.DEF)
        retrievePokemon=t.retrieve_pokemon()
        g=Gastly()

        self.assertEqual(retrievePokemon.pokemonName,g.pokemonName)

    def test_create_poke_team_0(self):
        """Test pokeTeam battlemode0 createPokeTeam() method"""
        t = PokeTeam("Dawn", [1, 1, 1, 1, 1], 0, PokeTeam.AI.RANDOM, Criterion.DEF)
        t.createPokeTeam([0, 0, 0, 0, 1], 0)
        pokemon=[]

        while not t.is_empty():
            pokemon.append(t.retrieve_pokemon())
        expected_classes = [Eevee]
        self.assertEqual(len(pokemon), len(expected_classes))
        for p, e in zip(pokemon, expected_classes):
            self.assertIsInstance(p, e)

    def test_create_poke_team_1(self):
        """Test pokeTeam battlemode1 createPokeTeam() method"""
        t = PokeTeam("Dawn", [1, 1, 1, 1, 1], 1, PokeTeam.AI.RANDOM, Criterion.DEF)
        t.createPokeTeam([0, 0, 0, 0, 1], 1)
        pokemon=[]

        while not t.is_empty():
            pokemon.append(t.retrieve_pokemon())
        expected_classes = [Eevee]
        self.assertEqual(len(pokemon), len(expected_classes))
        for p, e in zip(pokemon, expected_classes):
            self.assertIsInstance(p, e)

    def test_create_poke_team_2(self):
        """Test pokeTeam battlemode2 createPokeTeam() method"""
        t = PokeTeam("Dawn", [1, 1, 1, 1, 1], 2, PokeTeam.AI.RANDOM, Criterion.DEF)
        t.createSortPokemonTeam([0,0,1,0,1])
        pokemon=[]

        while not t.is_empty():
            pokemon.append(t.retrieve_pokemon())
        expected_classes = [Squirtle,Eevee]
        self.assertEqual(len(pokemon), len(expected_classes))
        for p, e in zip(pokemon, expected_classes):
            self.assertIsInstance(p, e)