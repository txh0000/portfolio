from __future__ import annotations

"""

pokemonBase is an abstract class which is inherited by the pokemon class.

"""
__author__ = "Scaffold by Jackson Goerner, Code by Lim Jun Kee, Lim Wei En, Heng Zi Ying, Toh Xi Heng"
from abc import ABC,abstractmethod
from random_gen import *
class PokemonBase(ABC):
    """
    Base class for pokemons. (Abstract class)

    Attributes:
        pokemonStatus (str): pokemon's status
        maxHealthPoint (int): pokemon's max health 
        currentHealthPoint (int): pokemon's current health
        pokemonType (PokeType): pokemon's element
        pokemonName (str): pokemon's name
        pokemonAttackDamage (int): pokemon's attack damage
        pokemonSpeed (int): pokemon's speed
        pokemonDefense (int): pokemon's defense
    """

    def __init__(self, hp: int, poke_type) -> None:
        """
        Method used to instantiate a pokemonBase object.
        """
        if type(hp)!=int or type(poke_type)!=int:
            raise ValueError
        self.maxHealthPoint=hp
        self.currentHealthPoint=hp
        self.pokemonType=poke_type
        self.pokemonSpeed=0
        self.pokemonAttackDamage=0
        self.pokemonDefence=0
        self.pokemonStatus="free"
        self.pokemonName=None





    def get_total_hp_lost(self):
        """
        Method using the maxHealthPoint - currentHealthPoint to find the total of health point lost.

        Return:
                the total of healt point lost.

        Best-case complexity: O(1)
        Worst-case complexity:O(1)
        """        

        return self.maxHealthPoint-self.currentHealthPoint



    def is_fainted(self) -> bool:
        """
        Method used to check if the pokemon is fainted (currentHealthPoint <= 0).

        Return:
                boolean True or False

        Best-case complexity: O(1)
        Worst-case complexity:O(1)
        """

        if self.currentHealthPoint<=0:
            return True
        else:
            return False

    @abstractmethod
    def level_up(self) -> None:
        """
        Child class implements this method.

        """
        pass



    def get_level(self) -> int:
        """
        Method used to get pokemonLevel of the pokemon.

        Return:
                pokemonLevel of pokemon.

        Best-case complexity: O(1)
        Worst-case complexity:O(1)
        """

        return self.pokemonLevel



    def get_speed(self) -> int:
        """
        Method used to get pokemonSpeed of the pokemon.

        Return:
                pokemonSpeed of pokemon.

        Best-case complexity: O(1)
        Worst-case complexity:O(1)
        """

        return self.pokemonSpeed



    def get_attack_damage(self) -> int:
        """
        Method used to get pokemonAttackDamage of the pokemon.

        Return: 
                pokemonAttackDamage of pokemon.

        Best-case complexity: O(1)
        Worst-case complexity:O(1)
        """

        return self.pokemonAttackDamage



    def get_defence(self) -> int:
        """
        Method used to get pokemonDefence of the pokemon.

        Return:
                pokemonDefence of pokemon.

        Best-case complexity: O(1)
        Worst-case complexity:O(1)
        """

        return self.pokemonDefence



    def get_hp(self):
        """
        Method used to get currentHealthPoint of the pokemon.

        Return:
                currentHealthPoint of pokemon.

        Best-case complexity: O(1)
        Worst-case complexity:O(1)
        """

        return self.currentHealthPoint



    def lose_hp(self, lost_hp: int) -> None:
        """
        Method used to reduce the currentHealthPoint of the pokemon.

        Parameter:
                lost_hp (int): integer of the amount of health to be reduced.

        Best-case complexity: O(1)
        Worst-case complexity:O(1)
        """

        self.currentHealthPoint-=lost_hp



    @abstractmethod
    def defend(self, damage: int) -> None:
        """
        Child class implements this method.

        """
        pass



    def attack(self, other: PokemonBase):
        """
        Method used to initiate an attack on another pokemon. This method is shared among all the pokemons.
        This method checks the attacking pokemon's status

        Parameter:
                other: the targeted pokemon

        Best-case complexity: O(1)
        Worst-case complexity:O(1)

        """        
        attackmultiplier=None

        # the pokemonType of the defending pokemon.
        otherPokemonType=other.pokemonType

        # Step 1: Calculate the attackmultiplier of the attacking pokemon

        # If the attacking pokemon does not have the "sleep" status, it calculates the attackmultiplier of it.
        # If the attacking pokemon has the "sleep" status, it does not attack.
        if self.pokemonStatus!="sleep":

            # Calculates the attackmultiplier according to the elements of the attacking and defending pokemons.
            if self.pokemonType==0:
                attackmultiplier=PokeType.fireAttackCalculation[otherPokemonType]

            elif self.pokemonType==1:
                attackmultiplier=PokeType.grassAttackCalculation[otherPokemonType]

            elif self.pokemonType==2:
                attackmultiplier=PokeType.waterAttackCalculation[otherPokemonType]

            elif self.pokemonType==3:
                attackmultiplier=PokeType.ghostAttackCalculation[otherPokemonType]

            elif self.pokemonType==4:
                attackmultiplier=PokeType.normalAttackCalculation[otherPokemonType]

            # Step 2: Status effects on attack damage / redirecting attacks
            # If the pokemon has the "confuse" status, it has a 50% chance of attacking itself.
            if self.pokemonStatus=="confuse" and RandomGen.random_chance(0.5)==True :
                # Ghost type pokemon
                if self.pokemonType==3:
                    effectiveDamage = (self.get_attack_damage() * 2)
                    self.defend(int(effectiveDamage))
                else:
                    effectiveDamage = (self.get_attack_damage() * 1)
                    self.defend(int(effectiveDamage))

                if self.pokemonStatus=="burn":
                    self.lose_hp(1)
                    
                elif self.pokemonStatus=="poison":
                    self.lose_hp(3)

            # It also has a chance to inflict a status on itself.
                if RandomGen.random_chance(0.2) == True:

                    if self.pokemonType == 0:
                        self.pokemonStatus = "burn"

                    elif self.pokemonType == 1:
                        self.pokemonStatus = "poison"

                    elif self.pokemonType == 2:
                        other.pokemonStatus = "paralysis"
                        self.pokemonSpeed //= 2

                    elif self.pokemonType == 3:
                        self.pokemonStatus = "sleep"

                    elif self.pokemonType == 4:
                        self.pokemonStatus = "confuse"


            else:
                if attackmultiplier==None:
                    raise Exception("attackMultiplier is None ")


                # If attacking pokemon has "burn" status, halves the effective attack.
                if self.pokemonStatus=="burn":
                    effectiveDamage=(self.get_attack_damage()*attackmultiplier)//2

                    other.defend(int(effectiveDamage))

                # Step 3: Do the attack
                else:

                    effectiveDamage = (self.get_attack_damage() * attackmultiplier)

                    other.defend(int(effectiveDamage))

                # Step 4: Losing hp to status effects
                # Losing hp to burn status effect
                if self.pokemonStatus=="burn":
                    self.lose_hp(1)

                # Losing hp to poison status effect
                elif self.pokemonStatus=="poison":
                    self.lose_hp(3)

                # Step 4: Possibly applying status effects on attacks
                if RandomGen.random_chance(0.2)==True:


                    if self.pokemonType==0:
                        other.pokemonStatus="burn"

                    elif self.pokemonType==1:
                        other.pokemonStatus="poison"

                    elif self.pokemonType==2:
                        other.pokemonStatus="paralysis"
                        other.pokemonSpeed//=2

                    elif self.pokemonType==3:
                        other.pokemonStatus="sleep"

                    elif self.pokemonType==4:
                        other.pokemonStatus="confuse"




    def get_poke_name(self) -> str:
        """
        Method used to get the pokemonName of the pokemon.

        Return:
                pokemonName of the pokemon.

        Best-case complexity: O(1)
        Worst-case complexity:O(1)
        """

        return self.pokemonName

    def __str__(self) -> str:
        """
        Method which is the string representation of the pokemonBase object.

        Best-case complexity: O(1)
        Worst-case complexity: O(1)
        """

        return f"LV. {self.get_level()} {self.get_poke_name()}: {self.get_hp()} HP"



    @abstractmethod
    def should_evolve(self) -> bool:
        """
        Child class implements this method.

        """
        pass



    @abstractmethod
    def can_evolve(self) -> bool:
        """
        Child class implements this method.

        """
        pass



    @abstractmethod
    def get_evolved_version(self) -> PokemonBase:
        """
        Child class implements this method.

        """
        pass



    def heal(self):
        """
        Method used to set the currentHealthPoint to the maxHealthPoint of the pokemon and change the pokemonStatus to "free".

        Best-case complexity: O(1)
        Worst-case complexity:O(1)
        """

        self.currentHealthPoint=self.maxHealthPoint
        self.pokemonStatus="free"



    def getAttackMultiplier(self,otherPokemon):
        """
        Method used to get the attackMultiplier according to the pokeType of the pokemons againts other pokeTypes.

        Best-case complexity: O(1)
        Worst-case complexity:O(1)
        """

        attackMultiplier=None
        otherPokemonType=otherPokemon.pokemonType

        if self.pokemonType == 0:
            attackMultiplier = PokeType.fireAttackCalculation[otherPokemonType]

        elif self.pokemonType == 1:
            attackMultiplier = PokeType.grassAttackCalculation[otherPokemonType]

        elif self.pokemonType == 2:
            attackMultiplier = PokeType.waterAttackCalculation[otherPokemonType]

        elif self.pokemonType == 3:
            attackMultiplier = PokeType.ghostAttackCalculation[otherPokemonType]

        elif self.pokemonType == 4:
            attackMultiplier = PokeType.normalAttackCalculation[otherPokemonType]

        if attackMultiplier==None:
            raise Exception("Wrong attackMultiplier")

        return attackMultiplier


class PokeType:
    """
    This is a class which contains the elements of pokemons and is used to do calculations for attack multiplier.
    """
    FIRE=0
    GRASS=1
    WATER=2
    GHOST=3
    NORMAL=4

    fireAttackCalculation=[1,2,0.5,1,1]
    grassAttackCalculation=[0.5,1,2,1,1]
    waterAttackCalculation = [2, 0.5, 1, 1, 1]
    ghostAttackCalculation = [1.25, 1.25, 1.25, 2, 0]
    normalAttackCalculation = [1.25, 1.25, 1.25, 0, 1]